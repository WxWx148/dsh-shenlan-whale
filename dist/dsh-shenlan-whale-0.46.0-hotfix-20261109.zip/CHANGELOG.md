## 0.46.0 — P1 收口：两条附带项 + truth 三件 + HTTP 往返守卫（2026-11-08）

P1 主体在 0.45.28 就完成了（12/12 父模块），但有两项「知道该做、当时没做」的欠账
一直挂在 §8.0 里：`ability → mind/life` 的依赖方向（R3）、`say.guardPlan` 的归属（R5）。
这一版把两笔都还了，把 truth 的第三件（manifest / audit）补齐，并把一直欠着的
「真机 HTTP 核对」变成一道可重复的守卫。

### 一、能力层不再认识心智层（R3）

以前 `ability/tools.mjs` 直接 import `../mind/index.mjs` 与 `../life/reminders.mjs`。
0.45.26 为此在文件里写了一行辩解：life 那边也依赖 ability，都走门面会成环，
所以「指向叶子文件断环干净」。能跑，但方向还是反的 —— **能力层替心智层决定了
「需求本怎么读」**，而且这种隐式副作用调用方看不见。

现在改成装配层注入：

```
createTools({ runtime, channel, usage, dir,
              mind: { addWant, dropWant, listWants, resolveWant, wantStats, refuse },
              life: { parseWhen, parseReminder, describeAt } })
```

19 处调用改成走注入对象。三个后果都是想要的：

| 后果 | 说明 |
| --- | --- |
| `ability/` 的依赖图里再没有 `mind/` `life/` | R3 的判据达成；`check-layers` 无新增边 |
| 没有心智层也能构造工具表 | 基准脚本、只读诊断不再被迫加载整个心智层 |
| 缺了就明说 | 返回 `code: 'not_wired'`，与「参数写错了」分开报，不假装成功 |

`life/reminders.mjs` 那个「环」也随之消失：`ability → life` 这条边整个没了，
不再需要「指向叶子文件」的例外。状态类工具（`my_status`）在缺注入时只少一行
「需求本还有几条」，不让整个状态查询失败 —— 降级要降在信息量上，不是降在可用性上。

用例里加了一条：不传 `mind`/`life` 时，`my_wants` / `set_reminder` 必须报 `not_wired`，
而 `my_status` 仍然成功。这条钉住的是**契约**，不是实现。

### 二、发言闸门搬到 `decide/`（R5）

`guardPlan`（沙箱执行前必须先说一句人话）原来长在 `voice/say.mjs` 里。于是
`ability/sandbox.mjs` 为了跑一段代码，不得不 import 表达层 —— 能力层去问表达层
「我能不能跑」，方向是反的。

现在它在 `decide/speech.mjs`：`voice/` 管「话说出来像不像人」（表达），
`decide/` 管「该不该说、说得够不够清楚」（判断）。判断逻辑一行未改，
文案与三条边界（空计划 / 超 5 步 / 单步超 60 字）原样保留。

`ability → voice` 这条边随之消失；`voice` 门面不再导出 `guardPlan`（一个符号
只能有一个来源，用例钉住 `'guardPlan' in voice === false`）。用例拆到
`tests/speech.test.mjs`，并补了两条边界（全空白项、前后空格）。

### 三、`mind/learn/` 真拆开，`weights` 独立

设计里的四分法（induction / habits / weights / selfcheck）以前只有前三件挤在
`mind/` 平铺、weights 根本不存在（混在 `evolve.mjs` 的 493 行里）。现在：

```
mind/learn/
  induction.mjs   归纳
  habits.mjs      习惯基线
  selfcheck.mjs   自查账本
  weights.mjs     四个旋钮的形状：上下限 / 默认值 / 校验 / 单步钳制（纯函数，无状态）
  evolve.mjs      怎么学：证据、窗口、版本、回滚（有状态，调 weights）
```

分开的判据很简单：**把 `weights.mjs` 单独拎出来，它应该能在任何地方跑**。
面板想显示「记忆留多久」，不该先造一个进化器。之前两个职责都说得通，
于是两边都不好改。

### 四、结构生成器扫不到子目录（一个静默失真）

拆 `mind/learn/` 时当场撞出来的：`scripts/gen-structure.mjs` 的 `scanDir`
只 `readdir` 一层。子目录里的 5 个文件在快照里**凭空消失**，文件数 73 → 69，
而 R2「规则的 symbol 必须真的被导出」照样全绿 —— 因为规则查的符号恰好都在门面里
还有一份。**少扫一个目录不报错，这才是最危险的失真**：父模块内部再分层之后，
快照会越来越像真的，实际上什么都没看见。

三处一起修：

| 位置 | 原来 | 现在 |
| --- | --- | --- |
| `gen-structure.scanDir` | 只扫一层 | 递归；`file` 是相对父模块的路径（含子目录） |
| `verify-copy-load` | 只扫一层，且必须手传副本路径 | 递归；不传路径时自动找宿主副本，找不到就如实说「这台机器没装」（不算失败） |
| 用例 | 无 | `tests/refactor.test.mjs` 新增一条：父模块里磁盘上的每个 `.mjs` 都必须在快照里 —— 双向比对，少扫/漏删都红 |

### 五、truth 三件齐了

`manifest` 一直空着不是忘了，是因为它**不该是第四个真源**。0.46.0 把它做成
一次合并投影（`truth/manifest.mjs`），三个投影全是现算的：

- `data()` — 96 个键的默认值 + 123 个面板项的元数据；
- `derive()` — 按分组 / 页面 / 域重新切一遍（界面和文档要的是这些切法）；
- `check()` — 六条对账：可编辑项没默认值、默认值没面板项、分组不存在、
  同一键登记两次、分组里没有项、只读项被标成可改。

判据很硬：改 `panel.mjs` 一行，`check()` 立刻跟着变；如果没变，说明这里藏了副本。
`npm run manifest:check` 进守卫，`manifest:dump --brief` 给出
「123 项面板（可改 96）· 96 个配置键 · 7 页」。

`audit`（`truth/audit.mjs`）只做一件事：**把口径写下来** —— 11 道守卫各叫什么、
证明什么、跑哪条命令、快还是慢。它不执行任何东西（truth 层不读盘、不起进程），
执行在 `scripts/audit-all.mjs`。于是「现在到底有几道、少跑一道会漏什么」有了唯一答案：

```
npm run audit            # 11 道全跑
npm run audit -- --fast  # 7 道提交前（1.6 秒）
```

### 六、欠了两版的「真机 HTTP 核对」变成守卫

0.45.18/0.45.19 一直挂着「待宿主 429 恢复后重启核对一次」。这句待办的问题是：
**它只能被人工做一次，做完就过期**。这版换成 `scripts/verify-http.mjs`：
起一个真实 `http.createServer`，把插件装进假宿主，在真实 socket 上把 14 条路由走一遍。

探针（probe11）是直接调 `handler(req,res)`，手搓的 req/res 没有 socket、没有真实
头部、不会自己关连接，所以这一类问题它永远看不见：content-type 写错、SSE 的
`cache-control` / `x-accel-buffering` 丢了、二进制被当字符串写回、404 不关连接。

它检查四件事：状态码 / content-type / 形状；被删的旧路由真的 404；错误体四字段
（`ok/error/code/hint`，且 `error` 是人话字符串）；12 个门面 + 30 个模块真实 import。

真跑出来的结果里，有两处**软 404 是有意的**，都已写进注释而不是「改成 400」：
`/detail?id=<不存在>` 返回 200 + 一张「没有这个页面」的空视图；业务失败体一律
200 + `ok:false`（前端只认 `ok` 与四个字段，这是既有契约）。

唯一跳过的一条：`POST /napcat/qr/refresh` 要协议端出码，假宿主里等不到。
它被标成 `skip` 并写明原因，不是「过了」。

### 七、三条刻意没做（不是忘了）

| 项 | 为什么不做 |
| --- | --- |
| `turn/index.mjs` 拆 7 段 | `#respond` 一个方法 1,040 行，全程共享 `this` 状态。拆成 stages 等于重排整条判定链的 await 顺序，而这类错误单测抓不住（要真机看回话节奏）。**没有真机窗口就不动它** —— 拆开的好处是可读性，坏处是可能悄悄改变行为，这个交换在收尾阶段不划算 |
| `ability/` 的 `tools/ exec/ media/` 三组子目录 | 拆 `tools` 要把 1,715 行按域切开并重做注册表（65 个工具的取用方式全变）。功能上零收益，风险上直接动工具层。已在门面头注释里写明「平铺，名字与职责一一对应，不画假结构」 |
| `view/client.panel.js`（3,428 行）拆分 | 宿主按 `dsh.client` **静态加载单个文件**。拆成多文件要同时改宿主入口，配错的表现是整个界面白屏且日志无报错。等能打开界面时一起做，届时是重写不是搬迁 |

这三条不影响「能装、能跑、能改」中的任何一条，只影响文件好不好读。
它们如实留在 §8.0 的待办表里，不写成「已完成」。

### 八、验收

| 项 | 结果 |
| --- | --- |
| `npm test` | **60 个文件全通过**（新增 manifest / speech 两个用例文件） |
| `npm run audit -- --fast` | 7/7（归属 / 文案 / 调用链 / 界面 R1–R15 / 结构 / 配置消费者 / 死码） |
| `npm run verify:http` | **0 项有问题**（14 条路由 + 旧路由 404 + 错误体四字段 + 30 个模块 import） |
| `npm run probe` | 4/4（probe8–11） |
| `npm run verify:copy` | **80/80** 模块真实 import（递归后才发现 learn/ 那 5 个以前没被加载过） |
| 结构 | 12 父模块落地 / 0 计划 / **76 文件** / 14 路由 / 343 导出 |
| 配置 | `audit:config` 96/96；`manifest:check` 无缺口 |
| 副本 | 一致 `v0.46.0`，18 项部署 / 1.52 MB |

**`npm test` 和 `npm run probe` 不再手写文件清单**：`tests/all.mjs` / `probes/all.mjs`
扫目录按名字排序逐个 spawn。以前那个长串是加法 —— 加新用例忘了改，表现是「全绿」，
不是「少一条」。这个项目用例已经 60 个文件，这种漏迟早发生，且不会有人发现。

## 0.45.28 — P1 第 12 批：`app/` 落地，P1 完成（12/12 父模块，2026-11-08）

`runtime` / `chat` / `host` / `events` / `action` / `asset` / `failure` / `build-info`
八件迁入 `app/`，门面导出 **23 个符号**；30 处 import 改走门面。

### 修掉一个从 0.45.20 起就在骗人的数

`app/build-info.mjs` 的 `RUNTIME_ENTRIES` 写死成
`['index.js', 'lib', 'base', 'channel', 'voice']` —— 它算的是「源码与副本一致吗」的
**内容指纹**。从 `facts/` 那一批开始，`truth/` `decide/` `turn/` `mind/` `ability/`
`life/` `view/` 里的代码全都不在这个清单里，于是：

> 只改这些目录 → 副本明明还是旧的 → 面板说 `same: true`（一致）。

这正是这个文件想解决的「改了没效果」，只是换了个位置发生，而且更隐蔽：
`check:sync` 用的是另一条路径（按 `blueprint.PARENTS` 部署 + 模块图自检），所以
**同步检查一直是绿的，只有面板上的那个数字是错的**。现在改成从 `PARENTS` 派生，
并实测：改一行 `facts/event.mjs` → 指纹变；还原 → 指纹回到原值。

### 三处刻意没搬

- **根 `index.js`**：`package.json` 的 `main`，宿主按这个路径加载插件。搬进 `app/` 要改宿主注册，而 `chat.deepseek.com` 仍 429、无真机窗口。
- **`lib/blueprint.mjs` / `structure.mjs` / `rules.mjs`**：三者都是**真源**（父模块声明、结构查询、规则登记），归 `truth/` 第二批，不塞进 app 制造新的错位。
- **`RISK` 不在门面转发**：唯一出处是 `truth/`（同 0.45.24 的 `BEHAVIOR`、0.45.27 的 `REGIONS`）。

顺带修了 `check-layers` 的入口清单（`lib/runtime.mjs` → `app/runtime.mjs`，
根 `index.js` 保留为入口）与 `check-ui` 里 5 处按路径读源码的位置。
R15 那条「index.js 必须引入 normalizeFailure」的正则原来把 `./lib/failure.mjs`
写死了，改成容忍门面路径 —— 钉的是形状不是路径。

### P1 到此完成

| 项 | 结果 |
| --- | --- |
| 12 个父模块 | **全部落地**，结构快照 12 落地 / 0 计划 |
| `lib/` 散装 | 50 → **3**（全是真源：blueprint / structure / rules）+ `client.panel.js` + `persona.default.md` |
| 验证 | `npm test` 全绿、R1–R15 全绿、调用链 150 文件 / 359 依赖无断链无环无越层、结构 72 文件 / 14 路由 |
| 副本 | 一致 `v0.45.28`，80 个运行时文件，`verify:copy` **72/72** |

**P1 的两条附带项仍未做**，如实记在 §8.0：`ability → mind/life` 改 `ctx` 注入（R3）、
`say.guardPlan` 迁 `decide/speech`（R5）。两条都要动 65 个工具的取用方式或重排发言闸门链，
属重构不属于搬迁。

## 0.45.27 — P1 第 11 批：`view/` 立起来，浏览器入口刻意不动（2026-11-08）

`panel-view` / `qqview` / `debug` / `list-view` 四件迁入 `view/`，门面导出 **22 个符号**；
16 处 import 改走门面，另修 7 处**字符串形式**的源码路径（`read`/`readSource`/
`readFileSync`/动态 `import`）—— 这类路径正则抓不到，漏一处就是「守检查的是旧文件」
或者「用例读的文件不存在」。

**`client.panel.js` 没搬，这是本批最重要的判断。** 它 3,427 行，设计里叫
`view/client.js`、约 1,200 行。但宿主是按 `package.json` 的 `dsh.client` **静态加载**它，
搬目录必须同时改宿主入口配置；当前 `chat.deepseek.com` 仍 429、没有真机窗口，
配错了表现是**整个界面白屏**，且日志里没有一行报错。加上它本来就是要按视图拆开的
重写（属重构不属搬迁），所以留在原地，等能打开界面时一起做。

`lib/rules.mjs`（规则登记表 + 定位）也没塞进 view：它是**真源**不是规则页，
与 `truth/` 同性质，等 truth 第二批一起归位。

**门面又少一个符号**：`REGIONS` 不在 view 门面再导出，唯一出处是 `truth/`。
这条规矩是被用例逼出来的——`tests/panel-view.test.mjs` 原本从 panel-view 拿 `REGIONS`，
改走门面后直接 `SyntaxError: does not provide an export named 'REGIONS'`。
处理方式是让用例改从 `truth/` 拿，而不是在门面上补一个转发（补转发会让
「REGIONS 归谁」重新变得含糊，和 0.45.24 的 `BEHAVIOR` 同一条原则）。

`npm test` 全绿、R1–R15 全绿、11 父模块落地 / 71 文件 / 14 路由、
`lib/` 散装 14 → 10；`audit:config` 96/96；副本一致 `v0.45.27`，`verify:copy` **71/71**。

## 0.45.26 — P1 第 10 批：`life/` 立起来，顺带撞上一个真实的环（2026-11-08）

`activity` / `reminders` / `activity-usage` 三件迁入 `life/`，门面导出 **11 个符号**；
14 处引用改走门面，两处头注释同步。

**这一批真的撞出环了。** 都改走门面之后，调用链立刻报：

```
ability/index.mjs → ability/tools.mjs → life/index.mjs → life/activity.mjs → ability/index.mjs
```

原因是 `life` 与 `ability` 本来就是**双向**依赖：`activity` 要联网（用 ability），
`tools` 要解析时间（用 life 的 reminders）。单文件时代看不出来，两边都改门面就成环。
处理方式是让一侧退让到文件级：`ability/tools.mjs` 指向 `../life/reminders.mjs`，
理由写在该 import 上方（`reminders` 是叶子模块，不依赖任何父模块，断环最干净），
`life/index.mjs` 的头注释也标了这条双向关系。**这是门面纪律的例外，不是疏漏**——
以后有人「规范化」回去，`npm run check` 会立刻红。

两处命名偏差刻意保留：设计里的 `meter.mjs` 就是 `activity-usage.mjs`（改名会把
「账本落盘 `activity-usage.json`」和「详情行 id `activity-usage`」两处数据契约搞乱）；
设计里的 `life/index.mjs`（160 行编排）没有独立文件，三段式活动本身由
`runActivityStep()` 串起来，再套一层编排只是空转发。

`npm test` 全绿、R1–R15 全绿、调用链 148 文件 / 346 依赖无断链无环无越层、
结构 **10 父模块落地 / 70 文件 / 14 路由**；`audit:config` 96/96、`audit:dead` 无新增；
副本一致 `v0.45.26`，`verify:copy` **70/70**。`lib/` 散装 17 → 14。

## 0.45.25 — P1 第 9 批：`ability/` 立起来（2026-11-08）

`skill` / `tools` / `sandbox` / `approvals` / `coding` / `media` / `stickers` /
`forward` / `web` / `browser` / `cdp` 十一件迁入 `ability/`，新增门面导出 **82 个符号**；
49 处引用改走门面，11 个文件头注释、`rules.mjs` 的 `pendingModule`、9 条审计描述串、
两处动态 import、一处 `readFileSync` 源码路径同步。

**一处真实的功能性路径**：`scripts/verify-coding-tools.mjs` 里
`tools.call('code_read', { path: 'lib/coding.mjs' })` 是**运行时**读自己源码，
不是注释也不是引用——不改的话这个自检工具会直接读不到文件。搬目录时这类
「字符串形式的真实路径」最容易被漏掉，因为它长得像普通字面量。

**三组子目录没拆**：`tools/`（index + 5 个域）、`exec/`（gate/runner/breaker/approvals）、
`media/`（images/stickers/forward）都留着设计态。拆 tools 要按域切开 1,712 行并重做
注册表，拆 exec 要把 sandbox 里「闸门 / 进程 / 配额」三段判定分开，拆 media 要区分
images/stickers/forward —— 三者都是重构，不是搬迁，等有真机窗口再做。

**两个 `LIMITS` 撞名**：`skill.mjs`（技能数量上限，外部有 2 处在读）保持 `LIMITS`，
`coding.mjs`（源码大小上限，外部无引用）以 `CODING_LIMITS` 导出。门面是唯一出口，
同名符号不能有两个来源。

跨父模块依赖：`tools` 还要用 `reminders`（属 `life/`，下一批搬），暂指 `../lib/reminders.mjs`，
`life/` 落地后改走 `../life/index.mjs`。`lib/` 散装 28 → 17。

`npm test` 全绿、R1–R15 全绿、调用链 147 文件 / 343 依赖无断链无越层、
结构 **9 父模块落地 / 69 文件 / 14 路由**；`rules` 的 `sandbox.confirm` 从
`pendingModule` 自动切到 `[structure] ability/approvals.mjs`；`audit:config` 96/96、
`audit:dead` 无新增；R6 报过发布清单漏 `ability/`，补完转绿；副本一致 `v0.45.25`，
`verify:copy` **69/69**。

## 0.45.24 — P1 第 8 批：`mind/` 立起来（2026-11-08）

`memory` / `persona` / `wants` / `refusals` / `induction` / `habits` / `selfcheck` /
`evolve` 八件迁入 `mind/`，新增门面导出 **32 个符号**；20 处引用改走门面，
8 个文件头注释、`rules.mjs` 的 `pendingModule`、审计描述串、用例动态 import 同步。

**`learn/` 子目录没拆。** 设计画着 `learn/{index,induction,habits,weights,selfcheck}`，
但 `weights.mjs` 从来不存在——四类权重的钳制、证据、版本回滚全在 `evolve.mjs` 里。
为了对齐设计先建子目录，只会得到「目录像设计、职责还是混的」的假结构，与前面
`facts/ledger`、`truth/manifest`、`decide/speech` 的判断一致：没有真实边界就不造壳。
门面头注释与 ARCHITECTURE 目录树如实标注，留待抽 weights 那一批一起做。

`evolve.mjs` 末尾的 `export { BEHAVIOR }` 是从 `decide/` 转发的，门面不再转一次——
同一个符号要有唯一出口，两个父模块都导出会让「BEHAVIOR 归谁」变得含糊。

依赖方向：`induction` / `habits` 用 `facts/`，`induction` / `evolve` 用 `decide/`，
均已在 L1 层级里向下，无环。`lib/` 散装 36 → 28。

`npm test` 全绿、R1–R15 全绿、调用链 146 文件 / 332 依赖无断链无越层、
结构 **8 父模块落地 / 68 文件 / 14 路由**；`audit:config` 96/96、`audit:dead` 无新增；
R6 报过发布清单漏 `mind/`，补完转绿；副本一致 `v0.45.24`，`verify:copy` **68/68**。

## 0.45.23 — P1 第 7 批：`turn/` 落地 + 副本加载验证补齐盲区（2026-11-08）

### 一、`turn/` 落地（只搬不改）

`lib/turn.mjs`（2,236 行单体）整体迁入 `turn/index.mjs`，创建父模块目录、落地
结构真源。10 处内部相对导入由 `./x.mjs` 改指 `../lib/x.mjs`（`turn/` 与 `lib/`
同级），其余 `../decide|facts|voice|truth|base` 依赖不变。外部导入全部改指
`turn/index.mjs`：`index.js`、`lib/chat.mjs`、`scripts/bench-prompt`、
`scripts/smoke-chain`、以及 6 个用例；3 条 `turn.*` 规则的 `pendingModule`
删掉，结构真源接管解析；注释与配置审计描述串同步。

**没有拆成 7 段。** 设计目标是把 `index.mjs` 缩成 260 行编排器、把
intake/understand/recall/compose/generate/tools-loop/emit 拆到 `stages/`。
但那是重写 `Turn` 类里重度共享 `this` 状态的方法，属判定链重构；宿主
`chat.deepseek.com` 持续 429、无真机窗口时不碰。目录树、§4.2 都改成标注现状，
拆分留 turn 第二批 —— 且届时**不动外部导入**（大家始终只认 `turn/index.mjs`）。

### 二、修掉副本加载验证的盲区（本批更重要的发现）

以前的副本验证脚本把目录写死成 `['lib','base','channel','voice']`，于是
`facts/truth/decide/turn` 里的模块**从没被真正 import 过** —— 前几批报的
「58/58、51/51 模块真实加载」只验证了四个目录，搬进父模块的模块没被验。
这类问题不报错：测试全绿、守卫全绿，只有宿主重启那一刻才可能炸
（`ERR_MODULE_NOT_FOUND` 已经踩过一次）。

新增 `scripts/verify-copy-load.mjs`（`npm run verify:copy -- <副本根>`）：
目录从副本自己的 `blueprint.PARENTS` 派生，覆盖全部 13 个目录。本次实测
**67/67 模块真实加载成功**（此前报的 51/51 是不完整的）。

### 三、验证

`npm test` 全绿、R1–R15 全绿、调用链 145 文件 / 324 依赖无断链无环无越层、
结构 **7 个父模块落地 / 67 文件 / 14 路由**；`audit:config`（96/96，turn 里的
`tools.*` / `self.*` / `images.*` / `usage.budgetPerDay` 消费者被覆盖）、
`audit:dead`、`probe`（0 问题）逐个跑过；副本一致 `v0.45.23`、
`verify:copy` 67/67 通过。

## 0.45.22 — P1 第 6 批：`decide/` 立起来，七件纯判断原样归位（2026-11-08）

### 一、七件纯判断归位

`behavior` / `attention` / `intent` / `guard` / `burst` / `cadence` / `dedupe`
迁入 `decide/`，新增 `decide/index.mjs` 门面导出 **34 个符号**。七件都是
纯判定（无 IO、无模型），内部依赖只指向已落地的 `facts/`（事件/窗口）和
`truth/`（能力/修正/自检规则）——`decide → facts/truth → base` 是 L1 层级里
合法向下的依赖，无跨层环。28 处引用改走门面，文件头注释、规则表的
`pendingModule`、配置审计脚本里的描述串、用例里的 `meta` 路径一并同步。

### 二、没做、也没造空壳

设计目录树画着 `route.mjs` / `intent.mjs` / `speech/` 三件合并（重构），实际
不存在。沿用前几批「只搬不改」纪律，七件整件迁移、判断逻辑一行不动，合并留到
decide 第二批——宿主 `chat.deepseek.com` 持续 429 限流、无真机窗口时，不碰判定链。
门面头注释、`ARCHITECTURE` 目录树与 §4.3 都改为标注现状，不画饼。

### 三、验证

`npm test` 全绿、`npm run check` R1–R15 全绿、调用链 144 文件 / 324 依赖
无断链无环无越层、结构 **6 个父模块落地 / 67 文件 / 14 路由**；`audit:config`
（96/96 有人读，decide 里的 `guard.*` / `group.followUpMaxTurns` 消费者被
上一批扩大的扫描范围正确覆盖）、`audit:dead`、`probe`（0 问题）逐个跑过；
副本 75 文件 / 51 模块真实 `import()` 全成功。升版 `0.45.22` 破宿主版本缓存。

## 0.45.21 — P1 第 5 批：`truth/` 立起来，顺带修掉一个审计盲区（2026-11-08）

### 一、四份真源归位

`config` / `panel` / `taxonomy` / `capabilities` 迁入 `truth/`，新增
`truth/index.mjs` 门面导出 **43 个符号**。四份都是不做 IO、不读运行时业务数据的
纯形状与清单，互相的依赖闭包是 `config → panel → taxonomy → blueprint`；
`blueprint.mjs` 按「设计声明」留在 `lib/`（生成器要读它，且它定义了含 truth
在内的 PARENTS）。37 处引用点改走门面，注释、动态 import、用例里的路径字符串
一并同步。

**最容易静默失效的一处**是 `gen-structure.mjs` 里硬编码的
`path.join(ROOT, 'lib', 'taxonomy.mjs')` 动态 import —— 搬走 taxonomy 后不改这里，
`npm run structure` 会直接崩。这一批先修它再跑生成器。

### 二、manifest 与 audit 这一批没做，也不造空壳

设计里 `truth` 是 `manifest / config / audit` 三件，目录树还画着一个
`manifest/`（data / derive / check 三投影）和一个 260 行的 `audit.mjs`。
查下来**两者都不存在**：三张清单目前是三个独立文件，八项对账散在
`scripts/check-*.mjs` 与 `tests/refactor.test.mjs` 里。

把三张清单并成一张是**重构**（96 键与 7 页导航的表示方式都要变），不是搬迁；
当前宿主认证限流、没有真机窗口。造一个 `truth/audit.mjs` 只会得到一层转调
脚本的空壳。所以这一批沿用前四批「只搬不改」的纪律，门面头注释与文档目录树
都改成标注现状，把合并留到 truth 第二批单独做。

另有一处**既有技术债**如实标出：`base/core.mjs` 反向 import 了
`DEFAULTS / clone / migrate / report`，按层级图 truth 在 base 之上，方向是错的。
修它要改 `loadConfig` 的注入方式，属于另一批，不因为搬了目录就说层级已干净。

### 三、顺带修掉一个真实的审计盲区

`check-config-consumers.mjs` 以前只扫 `lib/` 一个目录 —— `channel/`、`base/`、
`voice/`、`facts/` 里所有配置消费者都不在视野里。基线输出是
「96 键 / 89 有人读 / **7 个没人读**」。改成从 `blueprint.PARENTS` 派生扫描根目录
（目录存在就扫）后变成 96 / 0。

**没有只看数字变好看就接受**：逐键核实那 7 个的真实消费者分别在
`base/log.mjs`（4 个 `log.*`）、`facts/usage.mjs`（`inputPerM` / `outputPerM`）、
`channel/napcat.mjs`（`autoQr`）—— 全都是前几批从 `lib/` 搬出去的文件。
所以旧结论是扫描盲区造成的**假警报**，不是这 7 个开关真的空转。
`tests/config.test.mjs` 新增一条用例，同时断言「只扫 lib/ 会误报」与
「全目录不该误报」，把扫描范围钉住不许缩回去。

顺手删两个只定义不引用的死变量：`gen-structure.mjs` 的 `SCAN_DIRS`、
`check-config-consumers.mjs` 的 `LIB`。

### 四、验证

`npm test` 全绿、R1–R15 全绿、调用链 143 文件 / 317 依赖无断链无环无越层、
结构 **5 个父模块落地 / 66 文件 / 14 路由**。`npm run audit:config`、
`npm run audit:dead`、`npm run probe`（探针 11 共 0 项问题）三个不在主检查链里的
脚本也逐个跑过。副本同步时旧四个 `lib/` 文件被正确清掉、`truth/` 五件到位，
**74 个运行时文件 / 58 个模块真实 `import()` 全成功**。R6 在补 `package.json`
的 `files` 之前当场报红，补完转绿。

升版 `0.45.21` 破宿主 `name+version` 缓存。

## 0.45.20 — P1 第 4 批：`facts/` 立起来（2026-11-08）

### 一、只搬不改，两个部件落地

`lib/event.mjs`（打标）与 `lib/usage.mjs`（用量）迁入 `facts/`，新增
`facts/index.mjs` 门面导出 15 个符号。两件都只依赖 `node:` 内置，搬目录后
不需要重算任何内部相对路径；37 处引用点改走门面，文件头注释、规则表、
配置消费者表、用例里的动态 import 与字面量路径一并同步。

`lib/rules.mjs` 的 `usage.total` 原本写着 `parent:'facts'` + `pendingModule:'lib/usage.mjs'`，
搬完自动变成 `locatedBy:'structure'` → `facts/usage.mjs`，`pendingModule` 删掉。
**这条规则从手写路径切换成结构解析，正是当初把规则表改成 parent+symbol 的目的**——
这次是它第一次真的生效。

### 二、`ledger` 这一批没搬，也不假装搬了

设计里 `facts` 是 `event / ledger / usage` 三件，目录树还画着一个 420 行的
`ledger.mjs`。查下来**这个文件从来不存在**：四本账是 `lib/runtime.mjs` 用
`base/journal.mjs` 开的 events / behaviors / audit / cot / activities 五个账本，
读写方法散在 Runtime 里。硬造一个 `ledger.mjs` 只会得到一层什么都没管的转发，
门面看着齐了、判断还在 runtime，下次拆账本又得改一遍。所以门面只导出真实
存在的两件，头注释写明 ledger 的落点与「等拆 runtime 那一批再抽」。
文档目录树同步改成标注现状，不再留一张对不上的规划图。

### 三、名字相似但职责不同的，一个都没误搬

| 模块 | 实际职责 | 归属 |
|---|---|---|
| `lib/events.mjs` | SSE 状态摘要与订阅推送 | 接口层（UI-3b 新增），不记录事实 |
| `lib/activity-usage.mjs` | 自主活动自己的 token 小账 | `life/meter`，不是 `facts/usage` |

批量替换时正则过宽，一度把 6 处 `activity-usage.mjs` 也指向了新门面；
对照 HEAD 逐一还原后才继续。**这类误搬不会报错，只会让「活动自己的账」
悄悄接成「总账」**，所以宁可多花一轮核对。

### 四、验证

`npm test` 全绿、R1–R15 全绿、调用链 142 文件 / 313 依赖无断链无环无越层、
结构 4 个父模块落地 / 65 文件 / 14 路由。副本同步时旧的两个 `lib/` 文件被
正确清掉、`facts/` 三件到位，**73 个运行时文件 / 62 个模块真实 `import()` 全成功**。
R6 在补 `package.json` 的 `files` 之前当场报红（第 2 批曾因漏部署父模块导致
宿主 `ERR_MODULE_NOT_FOUND`），补完转绿。

升版 `0.45.20`：这批改的是运行时模块，但宿主按 `name+version` 缓存前端 bundle，
版本不动可能重启后仍加载旧模块。

## 0.45.19 — 统一错误体：把「没成功」变成「出了什么事 · 去哪改」（2026-11-08）

### 一、形状上的取舍：error 保持字符串

架构文档里画的是 `error:{code,message,hint,field}` 嵌套对象。落地时改成**并列字段**：

```js
{ ok:false, error:'空消息不发', code:'EMPTY_TEXT',
  hint:'在输入框里写点内容再点「发送」', field:'text', retry:false }
```

理由是界面有 **30 多处**把 `result.error` 当字符串直接显示（`say(result.error, 'bad')`
之类）。改成嵌套对象要同时改对这 30 处，漏一处的表现是「[object Object]」——
不报错、不崩溃、用例全绿，只有用户看到一句话变成了方块。当时宿主认证正被
429 限流，没有真机窗口可以逐屏核对，所以选了信息量相同、但零破坏的形状：
机器该有的 `code / hint / field / retry` 一个不少，人读的那句人话原地不动。
`R15` 会钉住这个形状，防止以后有人照文档改回去。

### 二、三处成对，缺一处就等于没做

| 层 | 改动 |
|---|---|
| `lib/failure.mjs`（新） | 16 个错误码的登记表 + `failure()` / `failureFrom()` / `normalizeFailure()` |
| `index.js` | 10 个 HTTP 错误出口全改走 `failure()`；`sendJson` 加最后一道归一，给几十个业务模块透传的 `ok:false` 补齐字段，**保留原有全部业务数据**（`items` / `checks` / `failed`） |
| `lib/action.mjs` | 6 个业务错误改走 `failure()`；27 项参数映射用例原样全绿，证明行为没变 |
| `lib/client.panel.js` | 新增 `readableError()`，在 `api()` 一处把 hint 拼进那句话；30 多个消费点一行未改 |

`normalizeFailure()` 有个刻意的例外：`/vision/selftest` 的 `ok:false` 是**自检结果**
不是错误，界面要逐条显示 `checks`。只有「有 `error` 字符串且没有 `code`」的响应
才补字段，已有 `code` 的显式错误体优先，不覆盖。

### 三、hint 不许是正确的废话

登记表里每条 hint 都指向一个**真实存在的入口**：「连接」页看通道、「设置 → 模型」
选 provider、「诊断」页看 `[whale]` 日志、输入框写内容再点发送、重启宿主重新加载
前端 bundle。确实没有可操作入口的（消息已被撤回），如实写「没有可操作入口」，
不编一个按钮出来。守卫会拦下「请重试 / 稍后再试」这类空话。

### 四、验证

- `tests/failure.test.mjs` **20 项**：登记表完整性与 hint 真实性、形状、
  未知码不吞、异常归一、不误伤成功响应/自检结果/数组。端到端分两段——
  把**真实前端函数体抠出来跑** `readableError()`，断言用户最后看到的是
  「空消息不发 · 在输入框里写点内容再点「发送」」；再把 `sendJson` 的真实函数体
  抠出来配一个假 `res` 跑，验证成功响应只多 `revision`、业务 `ok:false` 补齐字段
  且 `items/failed` 一个不少、显式错误体不被覆盖、自检结果与数组不被改写。
  宿主 429 下真机 HTTP 不通，这两段把**会发出去的字节**和**用户看到的那句话**
  都在离线环境证掉了；测的是源码本身，不是复制到用例里的一份。
- `check:ui` 新增 **R15**：HTTP 出口不许再手写错误体、error 不许变回对象、
  前端两处拼接都在、登记表不许出现废话 hint。**故意把 error 改成嵌套对象验证过会红**，随后还原。
- `npm test` 全绿、R1–R15 全绿、结构 14 条路由 / 64 文件；`action.test.mjs` 27 项
  与全量用例零失败，说明这次只加字段、没有改任何一处业务判断。
- 真机 HTTP 探测仍未做（宿主 429 限流 + web 层 502，见 0.45.18 第四节）。

## 0.45.18 — `/asset/:name` 落地：二进制资源归一口，写死前缀清零（15 → 14，2026-11-08）

### 一、先分清「资源」和「数据源」

界面里四个 `src` 长得一样，其实分两类：

| `src` | 回来的东西 | 归到哪 |
|---|---|---|
| 二维码 | PNG 字节 | `GET /asset/napcat/qr` |
| 落盘图片 | PNG/JPEG 字节 | `GET /asset/media/<名字>` |
| 看图自检 | JSON（自检项数组） | `GET /vision/selftest`，只把前缀改成 `apiUrl()` |
| 群列表 | JSON（群号与群名） | `GET /list/groups`，只把前缀改成 `apiUrl()` |

把后两个塞进资源口最省事，但「资源」就不再是一个能整体谈缓存、内容类型、
错误处理的类别了 —— 这正是前几刀一直在避免的**职责混用**。所以只收二进制。

### 二、路径穿越防护只留一份

以前 `/media/*` 靠 `mediaPath()` 的 `NAME_RE` 挡 `../`，`/napcat/qr` 从配置拿路径，
两面分开看都没问题，但「谁能读磁盘」这个判断散在两个分支里。现在统一先进
`lib/asset.mjs` 的 `assetOf()`：名字不认识就 `null` → 404，整条路径再挡一道
`..` / 反斜杠 / 空字节，媒体名继续走 `mediaPath()` 的白名单。未知名字**不猜
最接近的那个**——和 `/action`、`/list/:kind` 一个口径。

`tests/asset.test.mjs` 8 项：真临时目录里放一份 `config.json`，逐个验证
`../`、`%2f`、反斜杠、空字节都读不到它；另有一条端到端闭环——`assetUrl()`
拼出来的地址必须已在结构快照注册，去掉前缀后要能直接喂给 `assetOf()` 取回字节。
这一条堵的是「两端各自都对、拼起来差个前缀」这类最不容易被发现的不一致。

### 三、写死前缀清零

`lib/panel-view.mjs` 四处、`channel/napcat.mjs` 一处、探针两处，全部改走
`structure.assetUrl()` / `apiUrl()`。现在整个插件里只剩三处 `/api/shenlan`
字面量，每一处都是**定义**而不是**使用**：

- `blueprint.mjs` 的 `API_BASE`（前缀的唯一来源）
- `index.js` 的 `ROUTE_PREFIX`（宿主挂路由的那一处）
- `client.panel.js` 的 `API`（浏览器连上宿主之前，必须自己知道去哪拉 `/panel`）

`check:ui` 新增 **R14**：两端成对、旧资源路由不许回来、`assetUrl` 的每个名字
都在分派表里、`apiUrl` 的每个目标都真实存在、面板与登录层不许再写死前缀。
R4 里那条挂了很久的「等 P4 注册 /asset/:name」占位提示同时删掉，改回真检查。
另钉一处静默风险：`assetUrl()` 读 `structure.api.base`、宿主挂路由读
`index.js` 的 `ROUTE_PREFIX`，两处漂移的表现是「所有资源 404」，而 R4 共用
同一个 base 反而查不出来。故意把前缀改成 `/api/other` 验证过 R14 会红。

删 `/media/*` 与 `GET /napcat/qr`，加 `/asset/*`：**15 → 14 条路由**。

### 四、验证状态（如实）

- `npm test` 全绿；R1–R14 全绿；结构 14 条路由 / 63 文件；副本一致 `v0.45.18`。
- **副本 63/63 个运行时模块逐个真实 `import()` 成功** —— 这一刀给
  `channel/napcat.mjs` 新增了对 `lib/structure.mjs` 的引用，这是最容易在宿主里
  变成 `ERR_MODULE_NOT_FOUND` 的地方，先用真实加载把这条链证掉。
- **真机 HTTP 探测未做**：`chat.deepseek.com` 持续返回 429，宿主 web 转发层
  整体 502（`/panel` 也不通）。此时重启只会再撞一次认证失败并可能延长限流，
  所以没有动用户正在开的窗口。限流恢复后重启一次，核对
  `GET /asset/napcat/qr` / `/asset/media/<名字>` / 旧路径 404 即可。

## 0.45.17 — `/action` 把 21 条写动词路由收成一条（35 → 15，2026-11-08）

### 一、纪律：只搬不改

这二十一条路由全是写操作（改记忆、开关技能、发消息、重载配置…）。参数映射写错
不会报错，只会「点了没反应」或者改错用户的真实数据，所以这次**把每个分支的判断
原样搬过去**，不顺手改行为：

- `/memory/forget` 仍同时认 `target` 和 `text`（历史上传的字段不一致，只认一个就会删错东西）；
- `/skill` 仍只认 `on === true`，字符串 `'true'` 一律当关；
- `qq.send` 的三重保护（无会话 / 空消息 / 通道不在线）与「必须过 `runtime.outbound`」
  的同一套出站链一字未动。

### 二、做法

- **`lib/action.mjs`（新）**：`ACTION_OPS` 21 项清单 + `runAction(op, args, ctx)`。
  只返回数据、不碰 `res`；**未知 op 返回 null → 404**，绝不猜「最接近」的动作。
- **`index.js`**：删 21 个分支，只留 `POST /action { op, args }`。
  剩下 5 条 POST 是有意保留的：`/config`（架构规定独立）、`/debug/run`、`/chat`、
  `/napcat/qr/refresh`、`/vision/test`。
- **调用点一起收**：前端 28 处改走 `action(op, args)` helper；`probes/probe11.mjs`
  5 处改走 `/action`。R13 会逐个比对前端与探针用到的 op 名是否在清单里。
- **用例 `tests/action.test.mjs` 27 项**：19 个 op 的参数映射表驱动逐条核对，
  加上 `qq.send` 出站链与三重保护、`config.reload` 异步副作用合并、未知 op、
  `chat` 未接上时说人话。`tests/refactor.test.mjs` 一条旧断言跟着改 ——
  入口还在，只是换了统一口，查 op 名比查路径字面量更准。
- **R13**：清单 21 项、21 条旧路由消失、前端与探针的每个 op 都在清单里。

### 三、宿主副本实测（v0.45.17）

| 检查 | 结果 |
|---|---|
| `POST /action {op:'nope'}` | 404「没有这个操作：nope」 |
| `qq.send` 两条无副作用保护分支 | 「空消息不发」/「不知道发给谁」，分派与参数链路通 |
| 9 条旧写路由（抽样） | 全部 404 |
| `/list/status`、`/panel`、`/events` | 200；`/events` 长连接保持到客户端超时 |
| 回归 | `npm test` 全绿、R1–R13 全绿、结构快照 **15 条路由 / 62 文件**、副本一致 |

只测了无副作用的保护分支 —— 不为验证去改运行中的记忆、技能或配置。

### 四、UI-3b 还剩的

`/asset/:name` 收四处写死的资源 src、统一错误体。**路由数已低于 ≤26 的目标**。
再往下是 P1 第 4–12 批的模块归位。

## 0.45.16 — `/list/:kind` 把七条只读列表收成一条（41 → 35，2026-11-08）

### 一、收敛了什么

`/policy`、`/groups`、`/status`、`/skills`、`/memory`(GET)、`/usage`、`/approvals`(GET)
这七条都是「取一批数据」，却各占一条路由、各写一遍判断。界面、载荷、探针又把路径
写死在四处 —— 加一类要改三处，漏一处就静默 404，页面只是少块数据，不报一行错。

- **`lib/list-view.mjs`（新）**：`LIST_KINDS` 七类清单 + `listOf(kind, ctx)` 唯一实现。
  只返回数据、不碰 `res`，能被用例直接调；**未知 kind 返回 null**，调用方回 404，
  不猜也不兜底到别的类别。
- **`index.js`**：删掉七个分支，只留 `GET /list/:kind` 一条分派。`route.startsWith('/list/')`
  被结构快照记成 `/list/*`，R4 的 `hasRoute` 前缀匹配自动覆盖，不用给守卫开后门。
- **四个调用点一起改**：前端 `/policy` `/approvals` → `/list/policy` `/list/approvals`；
  群列表详情的 `src` → `/api/shenlan/list/groups`；探针 `/status` `/policy` 同理。
  只改服务端不改这些地方，是最典型的「收敛完界面瞎了」。
- **R12**：清单齐全、旧路由消失、四处写死路径不许回来；`tests/list-view.test.mjs` 7 项
  （七类都取得到 / 未知返回 null / 群名映射 / status 六源合并 / 时间戳可注入 / policy 归属与无归属 / memory 截断）。

### 二、宿主副本实测（v0.45.16）

| 检查 | 结果 |
|---|---|
| 七类 `/list/*` | 全部 200、`ok:true`，字段与旧实现一致（`status` 六源、`policy` 工具归属与白名单、`approvals` 待确认等） |
| `/list/nope` | 404 |
| 七条旧路径 | 全部 404 |
| `/detail?id=connection.groups` | `src = /api/shenlan/list/groups` |
| `/panel` | `v0.45.16` / 7 页导航 / 7 个区域，数据正常 |

`npm test` 全绿、R1–R12 全绿、结构快照 **35 条路由 / 61 文件**、副本一致。

### 三、还没做的

`/asset/:name` 收四处写死的资源 src、`POST /action {op,args}` 收二十条写动词路由、
统一错误体。35 → ≤26 主要靠 `/action` 那一刀。

## 0.45.15 — `/events` 事件流替掉 5 秒整包轮询（2026-11-08）

### 一、要省的不是请求数，是「每次都白算一遍」

`/panel` 一次要读文件、算统计、拼七个页面的卡片，而旧版每 5 秒无条件拉一次，
绝大多数回来的东西和上次一模一样。把轮询搬到服务端每秒推一次 `ping` 不叫优化，
那只是换个地方继续定时。

### 二、做法

- **宿主侧 `lib/events.mjs`**：`eventKeyOf` 每秒算一次**低成本摘要**
  （配置修订号 / 进度文本 / 待确认项 id / 通道状态 / 登录状态），每项单独兜底，
  某一项算不出来不拖垮整条链；`createEventHub` 没有订阅者时不跑定时器，
  最后一个窗口关掉就清表 —— 面板关着还每秒算一次，等于把省下的又加回去。
  定时器和时钟都从外面注入，用例能手动 `tick`，不用真等一秒。
- **`GET /events`（SSE）**：只推「该重拉了」，不推数据。数据仍由 `/panel` 一次算完，
  判断只留一处，前端不抄第二份状态。**只监听 `res` 的 close** ——
  Node 16+ 里 `req` 的 close 在请求体读完时也会触发，挂上去会把刚连上的 SSE 立刻关掉。
- **前端**：`EventSource` 收到 `invalidate` → `token+1` → 上面那个 effect 重拉一次；
  `ping` 不触发取数（这正是省下来的部分）。三条路都在：
  浏览器不支持 → 5 秒轮询；连不上/中途断 → 5 秒轮询（行为退回旧版，界面不会瞎）；
  连上了 → 仍留 20 秒低频兜底，摘要没覆盖到的字段最多晚 20 秒出现，不会「永远不刷新」。
- **一处有意重叠**：配置改动会让响应里的 `revision` 与 SSE 摘要同时触发，可能重拉两次。
  保留它是因为两者互补 —— `revision` 覆盖本窗口写操作，SSE 覆盖外部改配置；
  两次重拉的成本远小于每 5 秒整包拉一次。
- **没动** `/approvals` 1.5 秒、`process.cot` 2 秒、二维码 2.5 秒、250ms 走秒：
  那些是局部 UI 的实时性，塞进全局事件流只会让判断变复杂。

### 三、验证

- 新增 `tests/events.test.mjs` 9 项（首帧不推 / 变了才推 / 多窗口 / 停表 / 单个订阅者抛异常不拖垮 / 摘要残缺不崩 / `eventKeyOf` 覆盖配置与待确认项）；
- `npm test` 全绿；R1–R11 全绿；结构快照 41 条路由 / 60 文件；
- **宿主实测**：`curl -N --max-time 6 /api/shenlan/events` 收到 `: connected` 加 5 个每秒心跳，
  连接一直保持到客户端超时（`curl_exit=28`），宿主没有掐长连接；
- 副本一致 `v0.45.15`。

### 四、UI-3b 还剩的

40 → ≤26 的主体收敛（`/action` 收动词、`/list/:kind`、`/asset/:name`）与统一错误体。

## 0.45.14 — UI-3b 起步：删两条死接口、设置项补生效徽标（2026-11-08）

### 一、死接口 42 → 40

| 接口 | 为什么删 |
|---|---|
| `/brief` | 技能简报的只读出口，界面无入口、脚本与用例无调用方。运行时自己仍用 `skillBriefing()` 出站和做诊断，方法保留 |
| `/hotnews/test` | 绕过全部触发条件直接给主人私聊发一条热点，只用于早期手测；热点正常路径在 `runActivityStep` |

两个分支用到的符号（`searchWebDetailed` / `hotParts` / `outbound`）在别处仍在用，没留下死导入。
结构快照由 42 条路由自动降到 40；新增 **R10** 顺手钉住这两个路由不许回来。

### 二、生效徽标：改完到底什么时候起作用

以前只有一个 `needRestart` 布尔，改完没反应用户只能猜是不是没存上。现在：

- **数据侧**：`settingItemsOf` 每项带 `effect`（`pending` / `readonly` / `restart` / `next`）与中文 `badge`，
  翻译表只有一份；`pending` 优先于一切 —— 这一项连实现都还没接上，谈生效时机没意义。旧 `needRestart` 留着兼容。
- **界面侧**：常态「下一轮生效 / 只读」用轻量小字；「重启后生效」「改了也不会有变化」升级成醒目角标。
  123 行全套角标会把标题栏铺成一片色块，反而看不见真正需要动手的那几个。
- **钉住**：用例检查连接组每项都有 `effect`/`badge`、`channel.wsUrl` 明确是「重启后生效」；
  R10 要求数据侧与界面侧成对存在，少一边就红。

### 三、UI-3b 还没做完的

接口 42→≤26 的主体收敛（`/action` 收动词、`/list/:kind`、`/asset/:name`、`/events` SSE 替 5 秒轮询）
未开工，进度见 `ARCHITECTURE.md` §8.0。这一版先把没有争议的死重量卸掉、把用户能立刻看懂的徽标补上。

### 四、宿主副本实测

- `GET /detail?id=settings.channel`：13 项里 10 项「下一轮生效」、3 项「重启后生效」；
  `channel.wsUrl` = `{effect:'restart', badge:'重启后生效', needRestart:true}`；
- `/brief` 与 `/hotnews/test` 均返回 404；
- `npm test` 全绿、R1–R10 全绿、结构快照 40 条路由、副本一致 `v0.45.14`。

## 0.45.13 — 聊天输入框找回来了：宿主 125% 缩放把页面底部整块推出了窗口（2026-11-08）

> 0.45.5～0.45.12 是同一轮排查的中间态。宿主按「名字+版本」缓存前端 bundle，
> 每改一次都要升版、重启一次才看得见，所以合起来只留最后落地的行为。

### 一、症状

窄屏点开会话：消息能看、能翻，底部却始终没有输入框，像"这一页根本没法说话"。
按 CSS 高度链猜着改了两轮（`sticky` → `flex` → 绝对定位），截图里依旧没有输入框。

### 二、不猜了，让页面自己报

前端每次拉 `/panel` 时把现场几何带回服务端（`head.build.client.geo`）：九层元素的
`宽@左/高@上`、computed style、`elementFromPoint` 命中的是谁、`scrollHeight/clientHeight`、
`devicePixelRatio` 与视口在屏幕上的原点。定案靠的是这四行数：

```
dpr:1.25  scr:120,0/1296x824  composer:…/105@691  hit:slj-area
css:block/hidden/relative  comp:absolute/2/flex  scroll:2587/571
```

`hit:slj-area` 说明页面内部**完全正常**：输入栏就在那儿、在最上层、连命中测试都过了。
但系统缩放 125% 时，WebView 位图被放大了 1.25 倍，而布局视口（`innerHeight=816`）
没跟着缩 —— 窗口物理高只有 824，看得见的 CSS 高度约 `816/1.25=653`。
输入栏在 CSS `y=691…796`，换算成物理 `864…995`，**整块落在窗口外面**。
右边同理被裁掉 256px。这既不是插件样式写错，也不是截图工具的问题。

### 三、修法

- **几何补偿**：`1 < dpr < 1.6` 且 `outer ≈ inner`（说明两者同单位、没被换算过）时，
  可用的 CSS 视口取 `inner / dpr`。限定条件是故意的 —— 高分屏 `dpr=2` 里
  `outer` 已经是 DIP，再除一次会把界面无端缩成一半；
- **双向收缩**：横向按 `min(container, cssViewport - left)`、纵向按
  `min(height, cssViewportH - top)`，根节点自己收进可见区（本例 1002→746、776→613）；
- **回填几何**：首屏那次 `outerWidth` 常常还是 0，`ResizeObserver` 之后不会为
  "数值补齐了"再发通知。每次拉面板把现场测量回填进状态；
- **收缩直接落 DOM**（0.45.13 补的最后一环）：0.45.12 走的是
  `measureGeom → state → render → style prop`，实测自证已经写着
  `fix:on / cut:256x163`，根节点却仍是 1002×776 —— 状态链在首屏之后掉了一拍。
  现在每次渲染后重新量一次 DOM、直接写 `el.style.width/height`，数据每 5 秒
  回来一次就自动纠正，不依赖任何一次测量恰好赶上布局完成。R9 也钉住了这条；
- **底栏不吃高度链**：聊天页外层改成定位上下文 + `absolute inset:0`，
  `chatWrap` 当定位容器、输入栏 `absolute bottom` 加实底与 `z-index`，
  消息区自己滚并留 112px 底距。上面任何一层算不出确定高度，输入框也不会再跑掉。

### 四、守卫

`check:ui` 新增 **R9**：五条契约（定位上下文 / 绝对底栏 / 外层 `display:block` /
`dprFix` / 几何回填）缺一条就红。这类回归"改回去也不报错，只是又看不见了"。

### 五、验证状态

`npm test` 全绿；R1–R9 全绿（131 文件 / 294 依赖）；副本一致 `v0.45.13`。

**真机核对通过**（0.45.13，窗口 1295×823 / dpr 1.25）：

```
root:746x613@280,40  slot:746x613  cut:0x0
thread:626@368/372@251  composer:626@368/105@528  hit:slj-area
```

输入栏底边 CSS 633 → 物理 791 < 窗口 824，落在可见区内。截图确认：消息区自己滚、
底部分隔线 + textarea + 「发送」按钮完整可见，右侧有留白不再被裁。
（按钮呈禁用态是因为当时 QQ 通道掉线，界面按业务状态正确显示「现在发不出去」。）

期间宿主曾弹「Web authentication failed」：一晚重启十余次触发 `chat.deepseek.com`
**429** 限流。崩溃日志 renderer console 无任何 error、插件操作记录只是上下文，
属宿主认证限流而非插件故障；停止重启后自行恢复，本次 0.45.13 已正常加载。

## 0.45.4 — 界面按「看得见的宽度」排布；对话页窄屏一屏一件事（2026-11-07）

> 0.45.2 / 0.45.3 是同一次改动的中间态：宿主按「名字+版本」缓存前端 bundle，
> 每改一次样式都要升一次版本、重启一次才能看见。这里把三次合成一条记，
> 只留最后落地的行为。

### 一、右侧有没有被切：先让它变成可查的数

宿主给插件的容器宽度不一定等于窗口里能显示的那一块。以前插件内部报的「横向溢出」
永远是 0（`overflow:hidden` 自己吃掉了），于是「右边被切一半」这件事从代码上
怎么看都正常，只能靠截图猜。

- 前端上报从 2 个数扩成 5 个：`w` 宿主给多宽 / `vw` 视口多宽 / `left` 根节点从哪开始 /
  `ow` 因此被裁掉多少 / `geo` 分栏实测（nav/inner/side/main 的宽@左边界）；
- 断点改用**可见宽度** `min(container, viewport - left)`，不再用容器宽度；
- 真被裁时根节点把自己收到可见宽度（`data-slj-clipped="true"`），内容全部落回可见区；
- 量宽度优先量父节点：收窄之后量自己会得到收窄后的值，判断会在「裁 / 不裁」之间抖；
  宿主把槽位做成 `display:contents` 时父节点是 0，那就退回量自己并把见过的最大值记住。

### 二、对话页：窄屏一次只给一屏

以前不分宽窄都并排「会话列表 + 聊天」：实测 1002 宽时聊天列只剩 435，气泡里一行放不下
十二个字。现在窄屏走列表 → 整页对话（左上角「‹ 会话列表」返回），宽屏仍是两栏；
窄屏进页面不再自动打开第一个会话，先看列表；列表为空时说清是「这一类没有」还是「还没拉到」。

版本号一起动：宿主按 `名字+版本` 缓存前端 bundle。

## 0.45.1 — 修一个让整段样式失效的括号（2026-11-07）

补样式时漏写了一个 `}`，`.slj-navFoot` 之后的**全部规则**都被吃进那个没闭合的块里：
页面 DOM 正常、控制台一行红字都没有，只是没有边框、没有间距 —— 看起来像"样式没加载"。
截图对比能看出来，但没人会每次改样式都去截图比对。

- 补回括号；
- 新增守卫 **R8**：`check:ui` 静态校验样式表的括号平衡与首条规则存在，故意删一个 `}` 会当场红；
- 顺带修「预算还剩 1.600683」：一句话里所有金额统一两位小数（`usage.line`），并加用例钉住。

版本号一起动，是因为宿主按 `名字+版本` 缓存前端 bundle —— 只改内容不升版本，
重启后拿到的还是旧的那份。

## 0.45.0 — 十个页面并成六个；三栏；设置页不再有 123 个「保存」（2026-11-07）

### 一、页面 10 → 6 + 诊断

合并的判据不是"数量少好看"，而是**这两页回答的是不是同一个问题**：

| 新页 | 吸收 | 回答的问题 |
|---|---|---|
| 总览 | 概览 + 花费 | 它现在怎么样、今天花了多少 |
| 对话 | 对话 | 在跟谁说话、说了什么 |
| 心智 | 记忆 + 学习 | 记得什么、学到什么、能不能退回去 |
| 能力 | 技能 + 规则 | 会什么、被允许什么、被什么硬约束 |
| 连接 | QQ 连接 | 连上没有、怎么登录 |
| 设置 | 设置 | 我能改什么、什么时候生效 |
| 诊断 | 过程 | 出问题时去这里 |

实现上分成两层：`taxonomy.REGIONS` 决定"有哪些页"，`panel-view.PAGE_CARDS` 决定
"每页由哪几段拼成"。合并页面只改名单，不动内容 —— 否则每次调整划分都要动几百行。

旧的 6 个页面 id 全部留在 `blueprint.ALIASES` 里，随 `/panel` 下发；浏览器**不抄**这份表，
只负责翻译。旧书签、`localStorage` 里存的分区、详情 id 的前缀（`memory.*` / `skills.*`）
都按别名归位。同一页里重复的详情 id 只保留第一次出现的那个 —— 页面合并后必然撞
（总览和花费都有「今天的账」），重复的后果是 React 出现重复 key。

### 二、布局

- **宽屏（≥1080）三栏**：导航 / 列表 / 详情常驻，点开卡片不离开列表。
  不到 1080 时退回两级：点开详情**整页显示**，左上角给返回。
  实测 995px 窗口里三栏的详情只剩 400 出头，搜索框会被右边缘切掉 ——
  看得见一半比看不见更让人困惑，所以阈值定在 1080 而不是 900。
- 浏览器里的 `FALLBACK_NAV` / `FALLBACK_LAYOUT` 已删除。第一帧画骨架灰条，
  几何由 CSS 默认值撑住、数据到了再切内联宽度。页面清单与断点数字在浏览器里各只剩 0 份。

### 三、设置页

- **搜索**：名字 / 键名 / 说明 / 单位都能搜，右侧显示「N 项可改」或「N 项匹配」。
- **只读项折叠**：27 项不能改的东西收进「当前值（只读，N 项）」，默认收起。
- **批量保存**：草稿攒着，底部出现「N 项没保存 · 撤销 / 保存」，一次 `POST /config {items:[…]}`。
  每行右侧的「保存」按钮消失（原来 123 项就是 123 个按钮）。

  **不做"全成功或全失败"**：`setConfig` 是逐项落盘 + 逐项发通知，要在它上面假装事务，
  只能把校验逻辑复制一份出来，两份迟早不一致。服务端如实返回每一项的结果
  （`{ok, items:[已存], failed:[{key,error}]}`），界面直接说「存了 3 项；1 项没成：…」。

  两件事**不**进批量：标「危险」的项（要逐项确认，混进批量等于绕过确认）、
  留空的敏感项（留空＝不修改，不该当成一次写入）。

### 四、界面自报现场，不用截图猜

前端每次拉面板都带上 `?rev=<样式长度>&w=<实测宽度>&ow=<横向溢出量>`，
后端记进 `head.build.client`。排查"右边被切掉"这类问题时，
`curl /api/shenlan/panel` 就能读到「面板实际多宽、内容超没超」，不必截图对比。
本次自检结果：`width 1256 / overflow 0`。

## 0.44.0 — 界面按结构渲染；以及「改了代码为什么看不见」（2026-11-07）

### 一、界面不再手抄源码

结构搬进 `base/` `channel/` `voice/` 之后，界面里还有四类手抄：规则表 24 条路径、
页面清单 3 处、侧栏几何 2 处、接口前缀 3 处。搬一次目录就要人肉改一遍，
改漏了只能等测试报「文件不存在」。

现在：`lib/blueprint.mjs` 声明结构 → `npm run structure` 扫出快照 →
`lib/structure.mjs` 只负责查。规则表改成 `parent + symbol`，路径由结构解析；
模块卡从 10 个 `if` 改成 `CARD_PROVIDERS` 表；7 个概念域改成与父模块零重名的
`identity / speech / cognition / autonomy / capability / budget / runtime`。

新增 `npm run check:ui` 六条守卫，其中 R1 明确禁止界面代码里出现 `.mjs` 字面量 ——
只要界面不能写路径，它就只能查结构。

### 二、「改了代码，界面没变化」的三个真实原因

这一条是给下一次的自己看的，三个原因叠在一起，每一个单独都能让人以为改错了：

1. **样式注入不替换**。`injectStyle()` 发现同 id 的 `<style>` 就 `return`，
   注释却写着「热重载时换掉旧标签」。旧 CSS 永远留在 `document.head` 里。
   改成按内容比对：同内容不动，变了就改写现有标签。
2. **改错了组件**。设置页用的是 `.slj-splitRow`（左栏 + 右侧详情），
   不是 `.slj-mod`（整页卡片）。改一个不在这个页面上的选择器，什么都不会发生。
3. **宿主按 name+version 缓存前端**。版本号 `0.43.1` 从上线起没变过，
   内容改了也命中旧 bundle。现在升到 `0.44.0`，并把前端入口改名为
   `lib/client.panel.js` —— 文件名与版本号一起变，哪种缓存键都失效。

配套：`lib/build-info.mjs` 会在面板版本号下面报三种状态 ——
副本缺模块 / 磁盘比启动新 / 源码比副本新。前端每次拉面板带上 `?rev=`，
后端记进 `head.build.clientRev`，命令行就能确认页面跑的是哪一版前端。

### 三、界面密度

列表取代卡片墙：`.slj-mod` 与 `.slj-splitRow` 都去掉描边，改成 40px 左右的行
（图标 / 标题 / 一句说明 / 状态）；内容区上限 880 → 1120。设置页 13 组一屏可见。

### 四、同步与发布

`sync-to-profile` 的部署清单改为从 `blueprint.PARENTS` 派生，并在同步后检查
模块图是否闭合（副本缺目录会当场报）。此前清单手写六项，`base/` 没加进去，
副本缺整个目录而指纹仍说「一致」，插件加载直接 `ERR_MODULE_NOT_FOUND`。
`package.json` 的 `files` 补上三个父模块目录，`check:ui` 的 R6 守着这一条。

## 0.43.1 — 不再「一直想，然后没做成」；一条回复拆成三条只占一次额度（2026-11-07）

### 一、模型只输出思考、没有正文

线上 18:09 那次：`turn_failed: 模型没有返回文本`。`host.runner` 把思考分片和正文
一起算进 `maxTokens`（默认 800），思考长一点就把正文挤没了；旧逻辑直接抛错，
用户看到的是「正在想…」然后一张「没做成」。

现在：
- 默认输出上限 800 → 1600，给正文留出空间；
- 只有思考没有正文时，追加「只准给最终回复」再试一次；
- 两次都空、或者模型调用超时，改发一句人话「刚才想太久了，没接上。你再说一遍？」，
  不再走失败卡片，也不再让聊天框弹出内部错误；
- 重试的两次用量会合并记账，不偷漏成本。

### 二、一句话拆三条，额度只算一条回复

面板写的是「每分钟/每小时最多回几条」，但 `guard.note()` 是按**发送条数**记的：
一句话拆成三条气泡就吃掉 3 个额度，群里很快撞满 15 条/分钟，然后整个会话沉默。

现在：
- `guard.note(at, context, count)` 支持计数权重；`Turn.#say` 只在第一段记 1，
  后面几段记 0。拆几条都只算**一条回复**；
- 每条仍然更新 `lastAt`，条与条之间的间隔照旧按真实发送算；
- 分钟闸也按会话分桶：一个群刷屏不再让私聊和别的群跟着哑一分钟；
- 新增用例：三条气泡占一条额度、再回两条才到上限、别的群不受影响。

### 三、连接层：心跳、超时、重连本来就有；补上「掉线期间的消息」

核对 `lib/qq/onebot.mjs` 后确认：NapCat 每 30 秒推心跳、90 秒无帧判死、
15 秒体检、1→60 秒退避重连、重连后按时间补历史，这些都已经在代码里，
不是「只有一个收心跳」。真正缺的是**出站队列**：掉线时 `sendRaw` 直接拒绝，
那条回复就永久没了。

现在掉线期间只有 `send_*`（发消息）进队，查询类仍然当场拒绝；
连上后按原顺序补发；最多 50 条、5 分钟过期，断一晚上不会把旧话一股脑倒出来。
每条排队/补发/过期都写审计，事后能查「哪句迟到了、迟到多久」。

### 验证

```
npm test        53 个用例文件全过
npm run check   归属 / 文案 / 调用链三关全过
```

## 0.43.0 — 群聊不再被私聊拖哑；提醒接得住「明天 9 点」；失败提示只给主人（2026-11-07）

这一版修的是聊天里真实撞到的四个毛病，不新增能力。

### 一、群聊 @ 没反应：小时额度被私聊和别的群一起吃光了

面板写的是「每群每小时最多回几条」，`Guard` 却拿**全局发送数**去拦：
私聊、主动播报、别的群都算进同一个 20 条里。主人有豁免，所以私聊正常；
别人在群里 @ 它，`per_hour` 一拦就彻底沉默。线上日志里已经是
「这一小时已经说了 32 条」，而配置是 20。

现在按会话分开计数（`group:xxx` / `private:xxx`）。一个群刷满只关这个群，
别的群和私聊不受牵连；私聊仍按原来的全局口径。新增用例钉住
「一个群刷满，另一个群照样能回」。

另一个细节：多轮窗口里换成另一个人说话时，`followUpChance` 还会再随机淘汰一次，
即使那人已经在直接对深蓝说。现在「换人接话」由注意力判定一次，不再被概率二次吞掉；
概率只留给同一个人的续聊。

### 二、提醒：`time`/`content` 不再是耳边风

模型写 `{"time":"2026-11-08 09:00","content":"改毛病"}`，旧工具只认
`minutes`/`text`，于是时间落成默认 5 分钟、内容丢成「时间到了」。
现在：

- 认绝对时间：`明天早上 9 点`、`今晚 8 点半`、`2026-11-08 09:00`、`11 月 8 日 9 点`；
- 认相对时间：`5 分钟后`、`半小时后`、`3 天后`；
- 认别名：`time/at/when/date`、`content/message/what/note`；
- **给了时间但解析不出来就报错**，不再悄悄改成 5 分钟；没内容也报错，不再用「时间到了」冒充；
- 同一个人、同一分钟、同样内容只留一条；到点发不出去时不标记已发，半分钟后重试，不再永久丢提醒。

### 三、失败提示只对主人私聊展开

`没做成：…` 后面那句「可以让他/她换个做法再试一次」是内部话。
现在 `forQq` 默认不带 hint，只有主人私聊（`owner: true`）才展开；
群聊和别人的私聊保留正文，不砍正常聊天内容。面板仍然显示完整解释。

### 四、工具轮次不再默认 2 轮就卡死

`tools.maxRounds` 旧默认 2、硬夹 1~6。模型改提醒参数常常第二步才改对，
轮数先用完就只能回「我明早再改」。现在默认 **0 = 不限**（硬顶 24 轮，
由日预算和「同样调用换同样结果」判定收口），面板可填 0~24。
提示词里也写清了：改人设走 `read_persona/revise_persona`，改源码走
`code_read/code_write`，`exec_sandbox` 只跑临时脚本、只写 `out/`；
工具轮上限的键是 `tools.maxRounds`，不是 `maxToolRounds`。

### 验证

```
npm test        53 个用例文件全过（新增 tests/reminders.test.mjs 8 项）
npm run check   归属 / 文案 / 调用链三关全过
```

## 0.42.0 — 掉线自愈：2 分钟重启协议端，不再误杀你的 QQ（2026-11-07）

参考实现：[deepseek_QQFish_Service](https://github.com/jiangsuyuan/deepseek_QQFish_Service)
的 `scripts/watchdog.py`：3001 不通超过 2 分钟、不在等扫码 → 重启协议端，每小时最多 2 次。
深蓝原本也有看门狗，但有四个洞，合起来就是「掉线后再也回不来，但面板说 QQ 在跑」：

| 洞 | 原来会怎样 | 现在 |
|---|---|---|
| `agentRunning()` 先看 QQ.exe | 用户自己的 QQ 客户端也叫 QQ.exe，它常年开着 → 看门狗永远认为协议端在跑，NapCat 死了也不拉 | 只认 NapCat 自己的 node 进程（`qq-fish\napcat\` 下的 `napcat.mjs` / `index.js`）或 WebUI 6099；不再拿 QQ.exe 当判据 |
| `ensure()` 见 WebUI 还应答就返回「在跑」 | 账号已经离线（`1006514 网络连接异常`），WebUI 却活着 → 不重启，等到 NapCat 自己慢慢恢复（实测 5 分钟） | 新增 `recover()`：掉线 ≥2 分钟、不在等扫码、二维码不新、本小时额度没用完 → 真重启协议端 |
| 看门狗 5 分钟才动，每小时只给一次 | 一次没救回来就要等一小时 | 默认 2 分钟；每小时最多 2 次，计数写 `napcat-recovery.json`，DSH 重启不清零 |
| `kill()` 杀所有 `QQ.exe` | 会把用户正在聊的 QQ 一起关掉；NapCat 用的不是那个进程 | 只杀 NapCat 的 node 进程；杀完等 6099 释放再启动 |

顺带修了启动脚本：`启动NapCat.bat` 里写死了 `-q 1000000001`，插件传进来的
`-q <selfId>` 被吞掉 —— 启动的是旧号，不是当前机器人。现在脚本原样转发参数，
手动双击时默认用 1000000001（与 `channel.selfId` 一致）。

### 验证

```
npm test        52 个用例文件全过（新增 tests/napcat-recover.test.mjs 9 项）
npm run check   归属 / 文案 / 调用链三关全过
npm run smoke   18 项全通
```

新增用例钉住：用户 QQ.exe 不算 NapCat、2 分钟内不动、等扫码不动、二维码新不动、
3 分钟重启一次、每小时最多 2 次、杀进程命令里不许出现 `Get-Process QQ`。

## 0.41.0 — 更小、更省：闲聊少背一半工具表，静态前缀先进缓存（2026-11-07）

版本号从 0.40.0 抬到 0.41.0。这一版只做三件事：**把部署副本里不该有的东西拿掉、
把提示词的静态部分挪进缓存前缀、把工具结果回灌的重复结构删掉**。
没有删工具、没有改人格、没有动记忆策略。

### 一、体积：根目录 103.3 MB → 6.66 MB，宿主副本 2.46 MB → 1.28 MB

| 项 | 前 | 后 | 怎么做到的 |
|---|---:|---:|---|
| 插件根目录 | 103.3 MB | **6.66 MB** | 旧工作副本 `_archive` 与旧回滚点 / 回滚备份移到 `E:\深蓝鲸-archive\2026-11-07\`；根目录只留 r12 / r13 两个回滚点 |
| 宿主加载的副本 | 2.46 MB | **1.28 MB** | `sync-to-profile.mjs` 改成只部署运行时 6 项（index.js / lib / package.json / cordis.patch.yml / LICENSE / 启动脚本），同步时清掉 tests / scripts / probes / docs |
| 部署文件数 | 141 | **62** | 开发资产留在源码树，宿主一个字节都用不到 |

`npm test`、`npm run probe`、三个守卫仍然全部在源码树里跑，不受影响。
归档没有删，只是搬到了插件目录外面；根目录的 `ARCHIVE.md` 写了位置。

### 二、提示词：闲聊少背一半工具表，前缀命中率从 52% 到 86%

| 项 | 前 | 后 | 说明 |
|---|---:|---:|---|
| 闲聊提示词（在吗） | 3,978 字 | **3,039 字（−23.0%）** | 估算 1,735 → 1,469 token（−15.3%） |
| 动作提示词（查天气） | 3,985 字 | **3,773 字（−5.3%）** | 动作类仍然拿全表——省 token 不省能力 |
| 工具清单·闲聊 | 1,109 字 | **382 字** | 闲聊只列 26 个常用工具；`needsFullTools()` 命中动作词就回全表 |
| 能力说明（进提示词） | 318 字 | **174 字** | 不再把工具名抄第二遍；分组语义保留 |
| 静态前缀 | 1,881 字 | **2,604 字** | 灵魂 / 说话规则 / 表情表 / 工具清单 / 能力说明全部放到记忆之前；缓存按前缀命中 |
| 同一句记忆最多出现 | 2~3 次 | **1 次** | 事实 / 联想 / 相关旧记忆 / 人物备注统一按去标点后的整句判重 |

工具清单分档的边界写得很保守：`在吗 / 哈哈 / 晚安 / 嗯` 走闲聊档；
`查 / 搜 / 看 / 记 / 画 / 代码 / 文件 / 帮我 / 能不能 / 怎么 / 什么 / 群 / 说 / @` 等
只要沾一个就回全表。宁可多给，不把能做的事判成闲聊。

### 三、工具轮次：回灌不再抄 JSON

| 项 | 前 | 后 |
|---|---:|---:|
| 4 条长结果的回灌 | 7,355 字 | **5,600 字（−23.9%）** |
| 单条上限 / 整段上限 | 1,800 / 无 | **1,400 / 5,600** |

以前 `JSON.stringify(result).slice(0, 1800)`：换行被转义、`{ok,text,data}` 里给界面看的
`data` 也一起塞给模型。现在有 `text` 就只给正文，只补 path / url / count 这类标量元信息；
失败结果保留 `code` 与原因。模型要读的内容没少，重复结构没了。

### 四、验证

```
npm test        51 个用例文件全过（新增 tests/prompt-budget.test.mjs 8 项）
npm run check   归属 / 文案 / 调用链三关全过（135 个文件 / 275 条依赖）
npm run smoke   18 项全通（自检里关掉连发窗口，避免把 1.5 秒缓冲误判成「不回」）
npm run probe   探针 8~11 全过
npm run sync    profile 副本 v0.41.0，62 个运行时文件，1.28 MB
node scripts/bench-prompt.mjs   闲聊 3,039 字 / 静态前缀 86% / 工具回灌 −23.9%
```

**要重启 DeepSeek Harness** 才会加载新副本（进程内存里还是旧模块）。

## 质检 0.40.0 · 续轮：拆掉字数上限，两套切分并成一套（2026-11-07 07:30 起）

回滚点 `r12-去字数限制`。这一轮起因只有一句话 —— 主人要「去掉字数限制，他想说多长说多长」。
但代码里有三处「字数」在管着说话，其中两处早就坏了，还有一处把语气翻译成了配额。

| 缺陷 | 根因 | 现在 |
|---|---|---|
| **面板上的「每条最多几个字」旋钮一直空转** | 面板写 `persona.maxReplyChars`，运行时读 `options.partChars`，`styleOptions()` 又返回成 `maxChars` —— 三个名字没一个对得上。线上配的是 50，从没生效过 | 旋钮换成「话多话少」（简短／正常／爱聊）。它只改**语气倾向**，不设字数上限 |
| **问号被切分吃掉** | `splitReply` 用 `text.split(/[。！？!?…]+/)` 切句，分隔符连标点一起没了 ——「听不懂？」发出去是「听不懂」。深蓝 616 条消息里含问号的 **0 条**，而群里他人 37/575（6.4%）会扣问号 | 改成「在标点**之后**断，标点留着」。问号、感叹号是语气，不抹 |
| **换行被黏成逗号** | 两套并行实现里有一套把行首尾拼上逗号：「A\nB」发出去是「A，B」。这是深蓝逗号率 50%（真人 24%）的根因 | 切分只有一份实现，换行就是消息边界，不再黏合 |
| **两套切分各修各的** | `style.splitBursts`（按字数硬切）只被用例调用，运行时走的是 `turn.splitReply`（按逗号黏合）。两套早晚会再次对不上 | `splitReply` 改为转发，运行时只剩一条路径 |
| **「说话短一点」被翻译成「每条最多 12 字」** | 主人口令改的是 `persona.maxReplyChars` —— 把「语气」翻译成了「配额」 | 改 `persona.verbosity`：简短／正常／爱聊。字数不再参与 |

### 断句现在怎么判（`lib/semantic.mjs` + `lib/style.mjs`）

| 边界 | 什么时候断 | 为什么 |
|---|---|---|
| 换行 | 总是断 | 模型自己写了分行，就是想分成两条说（实测 71% 单行、19% 两行） |
| 句末标点 `。！？` | 后面能起头就断 | 模型自己封的句子，边界最硬 |
| 逗号 | 前面站得住 + 后面能起头 + 两边都不是碎片才断 | 「描述不同事实的几句各发一条」—— 主人原话 |
| 没有标点 | **不断** | 宁可长，不切碎。「真新／的」那种碎片是最难看的一种 |
| 超条数 | 尾巴并进最后一条，**按原来的间隔接回去** | 合并不能凭空造逗号，也不能超量发 |

只剩**下限**（别切出碎片），没有**上限**。字数下限 4 字是防碎片用的，不是「每条多少字」。

### 顺手修掉的

- `semantic.mjs` 的 `standsAlone` 拿错了词表：它用「不能起头」的词表去判「能不能收尾」，
  于是「我先看看啊」「行吧」「知道了」全被判成「话没说完」，该拆的永远拆不开。
  拆成两张表：能起头的（`STICKY`）／不能收尾的（`TAIL_STICKY`，只有的地得着过们）。
- `persona.maxParts` 面板下限从 2 改成 1 —— 主人口令「以后尽量一条说完」写的是 1，
  而面板下限是 2，改不动，那个口令一直是空转的。
- 探针 11 的沙箱断言过期了（写死要出现「执行器」三个字，那句早被改成大白话），
  改成断言「说的是人话、说的是真话」。

### 验证

- 全量用例：**857 项全绿**（含新增的 18 项说话手感用例：问号留住、换行不黏合、无字数上限、不切碎片）
- 三道守卫（归属／文案／调用链）+ 两项审计（配置消费者 91/91、公开面 0 死导出）
- 四个探针全绿
- 线上配置里的 `persona.maxReplyChars` 由迁移自动丢弃，`persona.verbosity` 自动补齐（不必手改）

## 质检 0.40.0 · 三轮（2026-11-07 03:00 起）

三轮都是「先全面检测，再完整优化迭代」。起点是本轮质检开始前的状态（`r7-起点`，815 断言全绿），
三轮各留一个回滚点：`r8-第一轮`（819）／`r9-第二轮`（827）／`r10-第三轮`（833）。

### 第一轮：教出来的技能是死的 + 提示词自相矛盾 + 缺限流器就崩

| 缺陷 | 根因 | 现在 |
|---|---|---|
| **教了等于没教** | 教技能的完整链路是「教 → 打开 → 生效」，而「生效」这一步是断的：技能清单只出现在面板和「你会什么」的回答里，**从来不进提示词**。主人教了「每天早上问好」，面板里亮着，模型压根不知道有这回事 | `lib/skill.mjs` 新增 `promptLineOf`：已开启的教出来技能写进提示词（「主人教过你这几件事，做的时候按这个来」）。默认关着的仍然不进（最小权限不变） |
| 提示词说「2~15 字，超过 20 字断下一条」 | 「每条多短」和「断句线」写在一句里，而断句线是用户可调的（12~150）。调到 150 时提示词变成「2~15 字，超过 150 字断下一条」—— 模型读到的是自相矛盾的指令 | 拆成两句，各说各的；规则块预算 220 → 260，否则最后一句会被 slice 掉 |
| 没装配限流器时整条消息崩掉 | `this.guard = input.guard` 之后 5 处（check/note/delay/mute/unmute）全是无保护调用，报「Cannot read properties of undefined」—— 用户看到的是「他/她突然不说话了」 | 缺限流器时用「什么都不拦」的替身：表现为不限流，而不是服务不可用 |
| 四段式结论规则与段名清单分叉 | 规则里硬写「【现象】【依据】【结论】【建议】」，清单单独导出没人用 —— 改一边不改另一边 | 规则句由清单生成，只有一处出处 |

### 第二轮：没断点的长话原样发出去 + 表情库存每次读盘

| 缺陷 | 根因 | 现在 |
|---|---|---|
| **说了「超过 N 字断下一条」却不断** | 断句只按换行与句末标点切，没有断点时整段原样发出去（实测 50 字一条）。`lib/style.mjs` 里有一套完整的 `splitBursts`（含硬切、码位安全），但**没有任何生产代码用它** —— 只有用例在调 | `splitReply` 复用 `style.mjs` 的 `hardWrap` 兜底：没有断点时按码位硬切，不劈开 emoji。实测超断句线的条数 3/3 → 0/7 |
| 表情库存每次面板刷新都重读 | `loadStickers` = 读 index.json + 逐张 `existsSync` + 一次 `readdir`，实测 0.75ms，占 `status()` 总耗时的一半以上 | 按目录状态缓存（目录列表 + index.json 的 mtime 与大小）。改了库存立刻失效，收藏完马上能用 |
| 表情库存零用例 | `tests/` 里根本没有 stickers 用例文件 | 新增 `tests/stickers.test.mjs`（5 项），并挂进 `npm test` |

### 第三轮：日预算不拦 + 「为什么没回」查不到

| 缺陷 | 根因 | 现在 |
|---|---|---|
| **日预算超了照花不误** | `usage.record()` 只把超预算**记**下来（`overBudget`），全项目没有任何地方读它。面板上明明白白写着「超过就会停下并提醒」，实际上一分钱都没少花 | `lib/turn.mjs` 新增 `#budgetGate`：超预算真的停下，并说清为什么。**主人豁免** —— 预算拦的是闲聊与自主活动，不是拦主人 |
| 自主活动绕过预算闸 | 预算闸只挂在回合入口，而「主动开口」「自主活动」「群里插话」各自起一次推理，绕开了回合入口 | 三条自主路径都过 `budgetBlocks()`；`runActivityStep` 内部再查一次（两次推理之间也可能超） |
| 预算正好用完不算超 | `over: cost > budget` —— 正好花到预算时 `left` 已是 0，面板显示「预算还剩 ¥0.00」却还在继续花钱 | 判定改 `>=`：用完了和超了是同一件事 —— 没有余额可用 |
| **「刚才为什么没理我」查不到** | 行为账本（`behaviors.jsonl`）一直在记每条消息的处置结果，但面板上没有任何入口看它；审计页只读另一本账（`audit.jsonl`）。主人看到「没理我」，能做的只有翻 QQ 记录或重启 | 新增「过程 → 没回的时候」：只列没回的那些，原因是人话（不是 `night`／`over_budget` 这种代号），带会话与时间 |
| 行为账本查不出是哪条消息 | `turn.mjs` 的 20 个 `outcome` 调用点没有一处传 `scope`／`conversation`，这两栏永远是空的 | `runtime.logEvent` 记一份事件→会话的内存索引，`outcome` 自动补齐 |
| 外部传进来的配置是残缺的 | `Runtime` 收到 `input.config` 就原样用，不走 `migrate` —— 传一份 `{identity:{ownerId}}` 进来，整份配置里就没有 `usage`，单价全是 0，预算永远是 0，面板显示「今天花了 ¥0.00」看不出任何异常 | `input.config` 也走 `migrate`：补默认值、修非法值、丢不认识的键 |
| 四段式段名清单成了死导出 | 规则改由清单生成后，export 就没人用了 | 收成私有；`SELF_CHECK_STATUS` 同样收掉 —— **死导出清零** |

### 三轮横向对比

| 项 | r7 起点 | r8 第一轮 | r9 第二轮 | r10 第三轮 |
|---|---|---|---|---|
| 断言数 | 815 | 819 | 827 | 833 |
| 用例耗时 | 67.1s | 66.9s | 67.4s | 67.1s |
| 守卫（归属／文案／调用链） | 绿 | 绿 | 绿 | 绿 |
| 死导出 | 2 个 | 2 个 | 2 个 | **0 个** |
| `runtime.status()` | 1.17 ms | 1.23 ms | **0.72 ms** | 0.72 ms |
| `panelView` 中位数 | 3.64 ms | 3.56 ms | 3.13 ms | **3.08 ms** |
| 超断句线的条数（3 段样本） | 3 / 3 | 3 / 3 | 0 / 7 | 0 / 7 |
| 不生效的开关 | 日预算（只记不拦） | 日预算 | 日预算 | **无** |

### 可复现性

```
node scripts/rollback.mjs list                       # 10 个回滚点
node scripts/rollback.mjs verify r10-第三轮          # 833 ✓
node scripts/rollback.mjs restore r7-起点 --yes      # 真回滚：815 ✓，新增用例被干净删除
node scripts/rollback.mjs restore r10-第三轮 --yes   # 退回：833 ✓，与快照逐字节一致
```

性能 A/B（同一台机器交替跑，三次无重叠）：`status()` 1.225/1.163/1.168 → 0.752/0.717/0.680；
`panelView` 3.63/3.64/4.06 → 3.07/3.08/3.19。

### 按界面承诺落实后的行为变化

日预算从「只记录」变成「真的拦」：**非主人**的对话在超预算后会被停下，并收到一句说明；
主人自己的对话不受影响。自主活动、主动开口、群里插话这三路也会停（静默，不发消息）。
如果不想让它停，把 `usage.budgetPerDay` 设成 0（= 不设上限）。

## 修复 · 自主活动独立记账、界面开关落到实处（2026-11-07 02:40）

| 缺陷 | 根因 | 现在 |
|---|---|---|
| 自主活动有时看不到 token 消耗 | 消耗只挂在思维链条目（`logCot.tokens`）；主动开口定时器、群聊插话这两路既不写带来源的 cot 也不记账；`spend()` 要求 runner 必须返回 `usage`，宿主换字段名就整笔静默丢失；「没想出搜索词」提前 return 也漏记 | 新增 `lib/activity-usage.mjs` 独立账本（`activity-usage.json`）：每一次自主推理都按天＋按动作分类落账，六种 usage 字段名都认；拿不到数字也记「一次调用·没拿到数字」＋审计；思维链 tokens 降为副本 |
| 界面上看不到自主活动的钱花在哪 | 自主活动详情页只列正文，token 只在思维链右侧显示 | 详情页顶部独立汇总（token／次数／花费／按动作拆分），每条正文旁带消耗标签；概览卡 badge 显示今日自主活动 token；调试台新增「自主活动用量」 |
| `net.allowlist` 是空转开关 | 界面白名单 UI 明写「全关表示不允许联网」，代码里却只有 `skill.mjs` 能力声明和 `tools.mjs` 自述文案在读，没有任何执行闸 | `lib/web.mjs` 新增统一联网闸：`checkNet` 按域名＋子域放行、`takeSlot` 按次数限流；`readWeb`／`searchWebDetailed`／工具／自主活动／热点全走这一道；改完由配置订阅者立即重装 |
| `net.quotaPerHour` 是空转开关 | 面板默认 60，`tools.mjs` 的 `web_search` 却写死 30 次/小时 | 配额由配置驱动，0＝不许联网；被拦时工具返回明确原因，不再伪装成「没搜到」；模型侧改为单独一行「这次没联网」，不混进搜索结果、不误记 `net.search` 技能 |
| 审计脚本报「89/89 全绿」是假绿 | 静态扫描把「提示词文案里出现键名」也算「有人读」，分不清「读出来显示」与「读出来拦请求」 | 新增 `BEHAVIOR_GATES` 行为闸名册（31 项执行处）＋ `CRITICAL_SWITCHES`（15 项关键开关）；脚本明确写出静态扫描的局限并输出行为闸核实结果；`npm test` 断言关键开关无缺闸 |
| 界面改完参数只能去 QQ 碰运气 | 调试台只核对「保存的值与磁盘是否一致」 | 「设置有没有生效」改显示**执行处**读到的真实值（白名单／次数／工具白名单／自主活动账本）；新增「联网开关试一次」，当场验证放行或被拦，试之前／之后的次数都摆出来 |

**按界面承诺落实后的行为变化**：`net.allowlist` 默认留空＝全部不许，所以升级后联网功能默认停用，启动时写一条 `net_policy_empty` 审计；在设置里点开或添加域名（如 `cn.bing.com`、`www.baidu.com`）即恢复，改完立即生效、无需重启。

**关于上轮「改了样子」的核实结论**：`tools.maxRounds`／`maxPerRound` 上轮只改了标签并从界面隐藏，行为本来就在工具环里，不是空转；本轮已把它们登记进行为闸名册并加断言。真正「只改样子」的是 `net.allowlist`／`net.quotaPerHour`，本轮补上了执行闸。

验证：新增 `tests/live-switches.test.mjs` 19 项；`npm test` exit 0；`npm run smoke` 18 项全通。

## 重构 · 自查复盘闭环、界面去技术化、数据调试台（2026-11-07 01:20）

参考 `jiangsuyuan/deepseek_QQFish_Service` 的做法：主人下达自查指令后立刻复盘并把结论交给主人；结论有状态闭环，不重复提交；界面只说人话。技术名词 `token` 按主人要求保留。

| 改了什么 | 原来会怎样 | 现在 |
|---|---|---|
| 能力事实源 `lib/capabilities.mjs` | 「能不能看别的群／能不能查自己代码」全靠模型猜，答成「看不到／不可能」 | 三层可见性（这场对话／一直记得的／可以现在查的）＋硬规则：不许把「没看到」说成「不存在」，被问到就真的调工具 |
| 意图路由 `lib/intent.mjs` | 诊断／修正／能力边界类指令没有落点；「查一下你代码」还会被送去联网搜一句话 | 一张意图表：诊断自动多给 4 轮工具、注入四段式结论规则、显示「正在核对数据」；自指说法不再走 `searchWeb`；修正类列出可修正项，不把问题推回主人 |
| 自查结论账本 `lib/selfcheck.mjs` | 同一问题反复提、结论没有状态 | 报告落盘＋`done` 标记＋内容去重；新增 `audit_self`／`my_patch_proposals`／`propose_patch`／`close_patch` 四个工具 |
| 工具能力说明 | `prompt()` 只给前 10 个示例，被 `code_*` 占满，跨会话工具没有例子 | 按主人常问什么排序；`my_capabilities` 改用能力事实源，不再手写一份自述 |
| 静默 | 限流提示 1 小时冷却、去重命中整条不发、失败卡片被拦，主人只能追问「你怎么又不说话」 | 冷却按原因分级（60 秒／5 分／30 分）且每次留痕；主人私聊里复读被拦发一句人话；长任务显示「正在核对数据」，回合结束自动撤掉 |
| 转发数据契约 | 非文本段静默丢弃并整条过滤 → 「我这边只拿到条数和时间」；首屏固定前 5 条；200 条上限不报真实总数 | 段类型全映射（@／图片／表情／卡片／语音／视频／文件／嵌套转发…）；CQ 字符串也解析；头部报真实总数与「这次先展开 N 条」；取失败写审计并在提示词里明说；首屏按字数自适应 |
| 界面口径 | 状态牌显示权重版本、第 N 版、第 x/y 轮、轮数上限、执行器、配置键名、`暂不生效` badge；「每一轮它是怎么想的」 | 全部改成人话（说话方式／还能接着聊多久／暂时用不了／改了也不会有变化）；`tools.maxRounds`／`maxPerRound` 不再作为旋钮露出，由任务类型自动决定（底层键保留）；`token` 相关文案保留 |
| 入口收敛 | 10 区域平铺、40 后端路由前端只接 18 个 | 侧栏按「说话与查看／它是什么样／数据与调试／连接与设置」四段呈现；区域 id 与顺序不变 |
| 数据调试台 `lib/debug.mjs` | 后端有重载／状态／用量／技能／转发核对能力，界面无入口；改完参数只能去 QQ 试 | 过程区新增「数据与调试」：选一份数据 → 跑一次 → 当场看结果；附「重新读取设置」按钮接上原本孤立的 `/config/reload` |

用例：新增 `tests/refactor.test.mjs` 16 条（含真实回合端到端：诊断指令的能力事实与结论规则确实进提示词、且没被送去联网）。`npm test` exit 0（45 个用例文件）、`npm run smoke` 18 项全通、`npm run sync` 后 `check:sync` 一致。**需重启 DeepSeek Harness** 加载新副本。

## 修复 · 界面改了不联动：配置变更没有统一事件源（2026-11-07 00:20）

线上表现：面板里改一项，提示「下一条消息就生效」，但相关行为与其它界面区块不动；
换个入口改（QQ 里说「说话短一点」、工具 `set_config`、直接改 config.json 后点重载）
更是各行其是。

| 缺陷 | 位置（修复前） | 现在 |
|---|---|---|
| 没有配置变更事件机制 | `lib/runtime.mjs` 的 `setConfig`/`reloadConfig` 只改内存 + `#reconfigure()`；`Runtime` 里完全没有订阅/广播 | `onConfigChange()` 订阅 + 单调递增 `configRevision` + `changedKeys` 前后 diff；两个入口共用一份 change 结构，订阅者抛错互相隔离 |
| 同步清单被抄在 HTTP 路由里，且抄了两份不一样的 | `index.js:1548` `/config/reload` 与 `index.js:1561` `/config`：各自手写 `guard/attention/usage/memory.configure`、`channel.config=`、`napcat.relink`；reload 那份还漏了登录重试、通道重连、启动项同步 | 装配处注册**唯一订阅者**，按 `changedKeys` 决定副作用；两个路由删成只合并异步 `effects`，任何入口改动都走同一段 |
| 构造时快照，改完还按旧值跑 | `runtime.mjs:128` 把记忆参数拷进 `WhaleMemory`；`#reconfigure()` 未通知它，只有那两个路由手工补过 | `#reconfigure()` 统一调 `memory.configure(this.config)`；`WhaleMemory` 新增 `enabled` 闸，读写都受控 |
| 配置就地改、缓存键却按对象身份判断 | `lib/skill.mjs:683` `snapshot.config !== config` —— `applyInto` 不换对象，这个比较永远 false；看过一次技能页后再改设置，清单永远停在旧状态 | `SkillBook.invalidate()` + `#reconfigure()` 显式作废；新增「先建缓存再改配置」回归用例 |
| 「长期记忆」开关只有文案在读 | `skill.mjs:244` 能力声明、`tools.mjs:1114` 提示词一句「记忆关着」，真正的 `digest()` 与 13 个写入方法都没判 | `WhaleMemory` 集中闸：关掉返回空快照、写入统一拒绝；重新打开立刻恢复且已有记忆不删 |
| 界面只刷新自己那一块 | `lib/client.js` 保存后 `setToken` 只重拉主数据 + 当前详情；外部改动最多靠 5 秒轮询，已打开的详情永远停在旧值 | 所有 HTTP 响应统一注入 `revision`；前端记住见过的修订号，变化就重拉主数据 + 详情，并区分「自己保存」与「别处改的」以免清掉正在编辑的草稿 |

用例：新增 `tests/config-sync.test.mjs` 10 条（广播/退订/异常隔离/effects/失败不推进修订号/reload diff/技能缓存失效/记忆开关/前后端契约）。
`npm test` exit 0（43 个用例文件）、`npm run smoke` 18 项全通、`npm run sync` 后 `check:sync` 一致。
**需重启 DeepSeek Harness** 才会加载新副本。

## 修复 · 转发读不完、最后一句没发出来（2026-11-06 23:55）

线上表现：一段 18 条的转发，模型连调三次 `read_forward_more`（每次参数都是 `{}`），
第三次之后聊天框一片空白 —— 用户什么也没收到。

| 缺陷 | 根因 | 现在 |
|---|---|---|
| 反复调同一个工具却不前进 | 不传参数时**固定从第 6 条起**，每次都拿到同一页，于是永远「还差 8 条」 | 按会话记游标：不传参数就接着上一页；`nextOffset` 报「这一页实际读掉几条」，截断时也不会漏 |
| 读到末尾还在返回「新内容」 | 读完后把 `from` 钳回最后一条，最后一条被当成新的一页反复返回 | 游标越过末尾即回「读完了，不要再用这个工具」 |
| 提示词说「共 4 条」、工具说「共 18 条」 | 头部统计用的是**合并后的段数**，没报原始条数 | 头部报原始条数，合并另说；截断提示改成「已读到的够就先回答」 |
| 一张空页 | 一条都放不进去时也截断，摘要为空 | 至少保留一条，保证每次翻页都有推进 |
| 最后一句没发出来 | 轮数用完时最后一行是 `[tool:…]`，清掉标记后正文为空 → 直接 return，什么都不发 | 补一次「只准回答」的收尾推理；收尾也失败就发一句兜底人话，绝不空白 |
| 白烧一轮 | 同一调用同一结果还继续喂，多花一次推理 | 检测到原地打转就停手，直接收尾（账不重复记） |

用例：回合 3 条（打转收口、轮数用完收尾、收尾失败兜底）+ 工具 3 条（原始条数、无参翻页、读完不重复）。
`npm test` 42 个用例文件 exit 0。

## 质检 0.40.0 · 夜间两轮（2026-11-06 21:45 起）

针对 21:23–21:37 那三处改动（记忆反义对、容错 JSON、拆句均分）做定向检测，
顺带把记忆读写路径的性能问题挖出来。回滚点：`r4-起点` / `r5-第一轮` / `r6-第二轮`。

### 第一轮：新代码里的缺陷

| 修了什么 | 原来会怎样 | 现在 |
|---|---|---|
| 改口判定（「爱吃辣→不爱吃辣」） | 两处成因叠加，**一条都识别不出来**：① 否定式包含肯定式（不爱吃 ⊃ 爱吃），旧写法被自己的排除条件判死；② 短句的全句重合度只有 0.33，先被话题闸拦掉 | 先判否定式、再比「抹掉态度词之后的剩余内容」，11 组正反例全对 |
| 容错 JSON 解析 | 全角标点被全局替换，**字符串里的内容被改写**：「喝咖啡，不加糖」收进来变成「喝咖啡,不加糖」 | 逐字走一遍、认字符串边界，只换结构位置的标点；全角大括号也认 |
| 工具名纠错 | 词序颠倒（`search_web`）距离算出 8，落到「猜不出来」——而这些功能存在的理由就是「一次改对」 | 加词集合比对；`search_web`/`fetch_web`/`webSearch` 都能指到真名 |
| 三处新逻辑零用例 | 断言数没变（753），改动没有被任何东西钉住 | 补 6 条用例（改口 2、容错解析 2、工具名 1、节流 1） |

### 第二轮：读页上限与记忆热路径

- **`readWeb` 没有响应体上限**：`await res.text()` 先整份读进内存再切片，切片只决定给模型看多少。
  一个把 .zip 当 text/html 返回的地址就能让进程涨几百兆，而这条路径是自动触发的（掉线自学、热点分享）。
  现在按 `content-length` 先拒、再边读边数，超 8MB 立刻停（实测 128MB 的流在 8.3MB 处中止，堆只涨到 9MB）。
- **`digest()` 每次调用要 750 ms**（2000 条事实）：邻居筛选在内层循环里现算 `normalize`，
  「每一跳 × 每个前沿 × 每一条事实」都跑两遍正则。归一化搬到循环外 + 按条目缓存二元组之后
  降到 **73 ms**（10.2 倍）。这条路径每条消息都跑一次。
- **每条消息都整份重写 `memory.json`**：digest 给选中的事实 +1 hits 就 `#save()`，
  2000 条时 300 KB × 每句话。改成窗口内攒着、`close()` 补写；顺带只在超上限时才裁数组。
  `rememberFact` 15.1 ms → 8.6 ms。
- 新增 `tests/web.test.mjs`（本地起服务，不碰外网），钉住「读到上限就停」这件事。

两轮之后的数：`npm test` 753 → **761** 断言，守卫全绿，`digest` −90%。

## 质检 0.40.0 · 三轮（2026-11-06）

版本号没动：三轮只修缺陷、不提能力。每轮都先存一个回滚点（`.snapshots/`），
并且都用「复制到临时目录跑全量用例」验证过退得回去。

### 第一轮：稳定性与性能

| 修了什么 | 原来会怎样 | 现在 |
|---|---|---|
| `run_command` 起 npm / npx | Node 18.20.2+ 禁止不带 shell 直接 spawn `.cmd`，实测 `spawn EINVAL`；承诺的三个程序只有 node 能用 | 直接起 `node "<cli.js>"`，不打开 shell，边界不变 |
| `code_write` / `code_restore` 写盘 | 写一半被杀就留半个源码文件 —— 插件下次起不来 | 临时文件 → fsync → rename，rename 失败才退回直写 |
| 11 个定时器 | `setInterval(async …)` 不等上一次返回：一次主动开口发两遍、自主活动烧双份 token | `lib/ticker.mjs` 重入闸，同名任务同一时刻只跑一份 |
| 状态文件（11 处） | 直接 `writeFileSync`，半截 JSON 静默回退默认值（当天计数归零 → 多发） | 一律走 `core.writeJson`（原子写） |
| 每日简报窗口 | 只在 09:00–09:01 触发，被一次慢 tick 跳过就整天不发 | 09:00 之后当天未发过就发（重复由 `state.day` 兜住） |
| 日志写入 | `appendFileSync` 每条 open+write+close：0.73 ms/条 | 常驻写句柄：0.061 ms/条（同一台机器 A/B，12 倍） |

### 第二轮：句柄、面板、模板文案

- **常驻句柄必须有人放**：补 `Journal#close()` → `ApprovalDesk` / `Sandbox` / `Runtime.close()`，
  卸载或重载之后不留悬空句柄（否则备份、搬目录会撞「文件正在使用」）。
- **面板每 2.5 秒刷一次，不许在算账上把钱花两遍**：`Journal#forEach` 一趟算完多个计数；
  确认台统计从四次全量扫描降到一次（2 万条记录热态 1.51 ms → 0.45 ms）。
- `#depth()` 改成从 0 号往上找、第一个缺口就停；`packageVersion()` 进进程内缓存
  （原来每次 `status()` 都读一遍 package.json）。
- 面板 `panelView` 中位数 4.29 ms → 3.51 ms（三次交替 A/B，无重叠）。
- 「记住结论后直接放行」的次数以前只在日志里，面板上数不出来；现在写在确认页副标题上。
- `splitBursts` 硬切按码位切，且不在 ZWJ / 变体选择符 / 肤色修饰符上断开 ——
  以前 `slice` 会把 emoji 劈成两半，发出去是半个字符。

### 第三轮：配置改了要真生效

- **最要紧的一条**：`setConfig` 以前是 `this.config = 新对象`，而 `Guard`、通道、注意力
  在装配时拿的是**旧引用**。于是面板改「每分钟最多几条」，提示说「下一条消息就生效」，
  实际一直是旧值 —— 不报错，只能靠重启或怀疑自己没点中。
  现在配置对象**只换内容、不换身份**（`config.applyInto`），`reloadConfig` 同样。
- 换原子写时顺手丢掉的东西补回来：`writeJson` 不抛异常，只返回 `{ ok:false }`，
  而这几份状态管着「今天发过没有」——写失败必须留一条日志，否则同一天会再发一遍且查不到。
- 回归用例：配置对象身份不变、白名单能被改小、`forEach` 与 `count` 口径一致、
  确认台统计与日志逐条对上、emoji 不被劈开、定时器重入与 `stop`。

三轮之后的数：`npm test` 740 → 753 断言，守卫（归属 / 文案 / 调用链）全绿，
`panelView` −18%，日志写入 −92%。

## 0.40.0 — 确认请求走渠道：QQ 私聊里回一句「同意」就算数

上一版把确认弹窗做出来了，但它只在面板里。人不在电脑前，请求只能等到超时被拒 ——
而它其实完全可以在 QQ 里问一句、在 QQ 里答一句。这一版补上渠道，并把「问什么」写清楚。

### 一、问人 ≠ 每次都问

| 档位 | 行为 |
|---|---|
| `free` | 不问，直接跑 |
| `off` | 不问，直接拒 |
| `ask` | 面板弹窗 **+** QQ 私聊，两条路一起问；谁先答算谁 |

这段判断放在静态闸门之后、真正执行之前，读的是**当前**配置 ——
面板上从 ask 改成 free 的那一刻起，排队的下一次就不再问。

### 二、QQ 私聊也能答

- 请求以系统消息直发主人私聊（不走打字台：60 秒的窗口等不起十几秒的字数延迟；
  也不吃夜间静音：没人看见等于默认拒绝，而用户根本不知道发生过）；
- 主人回 `同意` / `拒绝 理由` 即可。只认这四个字开头，**「行」「可以」不算** ——
  那几个词在闲聊里太常见，吃掉一条正常消息比漏掉一次确认更糟；
- 有多条在等时，必须带编号（id 末四位），猜一条等于放行错的那段代码；
- 没有等待项时，`同意` 照常进聊天，不会被吞掉；
- 回执也发回 QQ，并在事件流里留一条，聊天记录不缺这一句。

### 三、问的时候要说清「哪个项目、要干什么」

渠道消息与弹窗都写成：

```
【深蓝鲸】想跑一段代码，等你点头
项目：深蓝鲸
目的：算一次乘法
步骤：算乘法 → 打印结果
代码：console.log(6*7)
60 秒内不回按拒绝处理。回复「同意」执行，或者「拒绝 理由」不执行。
```

只写「要跑一段代码」的确认，点同意的人其实不知道自己同意了什么 —— 那不叫授权，叫盖章。

### 四、顺手修的真 bug

- `list()` 里编号字段和源码字段都叫 `code`，后者把前者覆盖了：
  表现是「回复了编号也不认」。现在编号叫 `ref`，源码叫 `code`。
- 出站的系统消息与打字路径现在共用同一个 `sendOne`，
  `channel.say` 回到 2 处（outbound + 面板代发），单一出口没有被这次改动破坏。
- 更要紧的一条：`index.js` 里 `const napcat = new NapCatLogin(...)` 被接进了上一行注释，
  整行变成了注释 —— `node --check` 通过、全量用例全绿，但桌面端一启动就 ReferenceError 起不来。
  新增 `tests/entry.test.mjs`：真加载入口 + 扫「注释里还写着声明」的行，这类事故以后会当场红。

### 五、验证

```
npm test        40 个用例文件全过（确认台 13 项、沙箱 27 项、入口 2 项）
npm run smoke   18 项全通（多验一遍：渠道消息里必须出现「项目 / 目的」）
```

## 0.39.0 — 「先问我」终于真的会问：确认弹窗、超时拒绝、记住选择与留档

0.34 起 `sandbox.mode` 就有 `ask` 这一档，但它一直是空的 —— 代码里写着
「这个版本还没有确认界面」。用户选了它，实际效果等于 `off`，而且还得自己发现这件事。
这一版把那一档补上，顺带把「累计总用量」补进 Token 概览。

### 一、确认弹窗（面板）

一段代码要被跑到之前，面板弹一个框：

- **两个按钮**：确认执行 / 取消并拒绝；
- **倒计时**：默认 60 秒（`sandbox.confirmSeconds`，10~300 可调），进度条 + 秒数一起走；
- **超时默认拒绝**：走完没人点，按「超时未确认」拒掉，绝不默认放行 ——
  默认允许的弹窗，只要人走开一次就变成一次静默授权；
- **记住我的选择**：勾上之后同类请求不再弹，结论落到 `sandbox/approvals.json`，
  随时能在「过程 → 沙箱确认」里清掉；
- **拒绝理由**：一直露在框里，取消时一并写进日志，也会回到模型手上
  （它看到的下一句话决定它会不会立刻重试）。

倒计时走完那一刻，浏览器会带着已经填好的理由提交一次；服务端再多等 2 秒才收口，
这 2 秒是留给那次提交在路上的时间 —— 否则理由永远写不进日志，用户填了也白填。

### 二、留档：问过、同意、拒绝、超时、记住、忘记，六种都记

- `sandbox/approvals.jsonl`：一次请求一行（`asked` / `allow` / `deny` / `timeout` /
  `remembered` / `forget` / `overflow`），带代码指纹、字节数、理由、耗时；
- 审计里同时落 `sandbox_ask` / `sandbox_approve` / `sandbox_reject`；
- 面板新增「沙箱确认」页：按请求去重（同一个请求的 asked 与 allow 只显示最后一条），
  超时写成「超时拒绝」，记住的结论置顶并带一个「清掉」按钮（两下确认）。

### 三、Token 概览加「累计总用量」

`usage.json` 原来只有按天账，90 天以外的天数会被裁掉 —— 拿它算「一共花了多少」，
越用越少。现在拆成两本：

- `days`：按天切、保留 90 天，算今天、算预算；
- `total`：只增不减，算累计；老账本第一次读到时会按现有天数补算一次并落盘，
  面板上写明「从哪天起」，不假装是开天辟地以来的数。

概览多一块「累计 token」状态牌，「今天的账」多一张「累计总用量」卡。

### 四、顺手修的一个假绿灯

`npm run smoke` 之前带着默认的 23:00–07:00 夜间静音跑，凌晨执行会有一半用例红在
「现在是夜间静音时段」。现在开场就把静音窗口关掉 —— 自检验的是链路，不是现在几点。

### 五、验证

```
npm test        39 个用例文件全过（新增确认台 7 项、沙箱 ask 3 项、累计用量 3 项）
npm run smoke   18 项全通（新增「ask 档挂起 → 同意 → 真跑」）
```

## 0.38.0 — 排查一轮：修掉三处会卡死、会漏、会看不见的毛病

这一版不加新能力，只做三件事：**把会卡死的地方修好、把装了却看不见的模块摆到面板上、
把「生成 + 打字」两段等待合成一段。**

### 一、三个真 bug（都带用例钉住）

| 症状 | 根因 | 修法 |
|---|---|---|
| 一旦有一条出站抛错，之后**所有回复都发不出去**，进程不报错 | `TypingDesk.#serial` 里 `await prev` 写在 try 外面，队尾 Promise 一旦 reject，闸门永远不放行 | 把 `await prev` 收进 try，上一条炸了照样放行 |
| 长跑越用越占内存；群里「明明没人刚说完话，却显示还热着」 | `lastReply` 只为换人判定服务，却从不清理；`otherTarget` 遇到过期项只 skip 不删 | 窗口一关就连带清掉那句话；扫过期项时顺手删 |
| 打字台、注意力装了却**在面板上完全不存在** | 0.35 只接了链路，没接视图：panelView 根本没拿到这两个对象 | 概览加两颗状态牌 + 一张「说话的节奏」卡，点开是两个新详情页 |

### 二、体感：两段等待并成一段

以前「模型想 6 秒」+「按字数再等 8 秒」= 14 秒，前 6 秒聊天窗口是**完全静止**的。

- **决定要回的那一刻就亮「正在输入」**（不等生成完）。这 6 秒里对方已经看见反馈。
- 打字时长**扣掉已经花掉的时间**：`planned = max(0, 打字时长 - 已等时间)`，
  总等待从「生成 + 打字」变成「max(生成, 打字)」左右。
- 有人在排队时让路：单条最多打 4 秒（`TYPING.crowdedCapSec`），段间隔也收窄。
  以前一条长回复能把别人压 15 秒，群里刷屏时越积越久。
- 同一条回复不会亮两次「正在输入」（会闪）—— 提前亮过的会记账，typeOut 认领一次即销。

### 三、侧边栏显示版本号

改完重启没变化时，第一件事是确认宿主加载的是哪一版。现在品牌名下面直接写 `v0.38.0`；
数字没动 = 还在跑旧副本，别在界面里找原因。

### 四、验证

```
npm test        38 个用例文件全过（打字台 16 项、注意力 16 项、页面骨架 40 项）
npm run smoke   17 项全通（面板多两个新模块页也能打开）
```

## 0.37.0 — 面板补上「规则」：只写现在，不写改动

这一版不加说话能力，补的是**「它现在按什么跑」没有一个地方能看**。之前的 14 条规则只活在
变更看板里，而看板是给「这次改了什么」用的；用户日常打开面板，看不到约束、顺序和已知缺口。
变更看板也不该搬进面板 —— 面板只留此刻能照着做的规则，历史归看板。

### 一、新增「规则」区（第十个区域）

- `lib/rules.mjs` 是唯一来源：22 条硬约束 + 4 项已知缺口，分五组（节奏与注意力 / 通道与事件 /
  回合与路由 / 入口与出站 / 工具链与元信息），分组名与变更看板一致。
- 「全部规则」一页按组排开，可搜关键词、模块或位置；单组页只留该组，不再重复画组标题。
- 每条规则四件事：**叫什么 · 约束正文 · 落在哪个模块 · 现场值**。现场值读当前配置
  （比如注意力窗口是 180 秒 / 20 轮、工具环最多 2 轮），正文不写死数字，规则和设置不会各说一套。
- 「还没接上」单列一页：连发合并、换目标的模型判定、说说/朋友圈、跨群记忆。每条都写
  「现在是什么 / 为什么没做 / 下一步要付什么代价」，不把未接写成已支持。
- 概览加一张「现在按什么规则跑」入口卡；设置页 12 张卡按域（身份 / 表达 / 心智 / 自主 /
  能力 / 花费 / 运行）分段，不再是一堵平铺的墙。

### 二、把过时的说明改成现行口径

- 「说话的节奏」里 `firstDelayMs` / `minGapMs` 改成「下限」口径：打字台按字数算等待，
  这两个值只是地板，不再是「看到消息固定等多久」。
- `group.followUpSeconds` / `followUpMaxTurns` 说明改成**按人开窗**：同一个人一个窗口，
  窗口内不 @ 也接，到轮数上限关窗。
- `guard.mergeWindowMs` 不再假装「连续几条合并成一次回」：它现在只打 burst 标签，
  不会合并。这一条写进「还没接上」，并在设置项说明里点名 —— 但它**不进 PENDING_KEYS**，
  因为那份名册的定义是「没有任何代码读」，破坏这条断言会让「空转」失真。

### 三、验证

```
npm test        38 个用例文件全过（新增 tests/rules.test.mjs 8 项）
npm run smoke   17 项全通
npm run probe   104 项全过
```

规则用例钉住四件事：每条规则指向的模块必须存在；正文不许出现「以前 / 旧版」这类历史叙述；
现场值随配置变；规则页在空输入下也打得开。

## 0.36.1 — 变更看板：把改动摊成能查的三张表

给「这次到底改了什么」一个能看的地方。不是手写文档，是**从两份真实源码切出来**生成的单页：

- `scripts/changes-board.mjs` + `npm run board` → `docs/changes.html`（单文件、零依赖、file:// 可开）。
- 三个视图：**变更**（按新增模块 / 细则微调分类，逐条 diff）、**规则清单**（14 条此刻仍生效的约束）、
  **验证矩阵**（5 条命令各证明哪段链路，最近结果）。
- 顶部三条主线卡片直通对应条目；左侧目录按分区（节奏与注意力 / 通道与事件 / 回合与路由 / 入口与出站 / 工具链）分组。
- 筛选：类型 + 分区 + 全文搜索（连代码片段一起搜）；跳转：点目录、`j`/`k` 上下条、`1`/`2`/`3` 切视图、`#c=条目` 可分享。
- 数据纪律：代码片段与行号从基线 `深蓝鲸.bak-*` 里切，锚点找不到直接报错退出 ——
  宁可生成失败，也不要生成一份「看着像、其实对不上代码」的看板。

顺带改正 0.36.0 里写错的数字：用例文件是 **37** 个（`tests/*.test.mjs`），不是 38。

## 0.36.0 — 全链路收口：出站只有一个口，另外给了它一条能自己跑的体检

这一版不新增说话能力，只做「关节」：把散在几处的出站收成一条路，把只在静态守卫里
「看起来没问题」的部分拿真链路跑一遍。

### 一、出站收成一个口（12 处 → 2 处）

定时器、告警、提醒、主动开口原先各自 `await channel.say(...)`，代价有三个：

| 症状 | 根因 |
|---|---|
| 回话像人、播报像广播 | 打字台只接在 `turn.#say` 上，定时器绕过去了：没有「正在输入」、没有字数节奏、不分条 |
| 额度算不准 | 有的地方记 `guard.note`、有的忘了；同一小时里「回话」和「播报」两套计数 |
| 上下文缺一半 | 有的记了 `noteSelfMessage`，有的没记 —— 拼上下文时它看不见自己播报过什么 |

现在只有 `outbound(scope, target, parts, options)` 一条路：**闸门 → 打字台 → 通道 → 记账**。
被替换的 10 处：主动开口、每日简报、热点（定时 + 面板两处）、群插话、预算告警、早间补回、
冷群话题、到点提醒。面板「代发」保留直连 —— 用户点了发送，等的是立刻出去，不是像人打字。

### 二、通知与请求不再被通道吞掉

`toRaw` 以前对 `notice` / `request` 一律 `return null`，于是「被戳一戳」「有人申请加好友」
「有人拉它进群」三件事**从来没进过系统**：事件流、面板、审计里都查不到，主人只能自己在 QQ 里发现。

- 两类事件现在翻成 `kind=notice` 的 raw：戳一戳带 `payload.notice`，请求带
  `payload.request{flag, subType, groupId, userId, comment}`。
- 路由层照旧「通知只记录，不产生行为」——它不该回话，但不该不存在。
- 申请类事件额外由入口转告主人一句，并明确写「同意这一步我不代劳」：
  替主人把陌生人放进来是权限决定，不是聊天。
- 脏包（没有 `notice_type` / 没有 `flag`）仍然返回 `null`：缺 `flag` 的请求既不能同意也不能拒绝。

### 三、新增 `npm run smoke`：全链路自检 17 项

`scripts/smoke-chain.mjs`：临时目录 + 假通道 + 假模型，其余全是真模块，跑一遍
「消息进来 → 路由 → 闸门 → 提示词 → 生成 → 工具环 → 分条 → 打字台 → 出站 → 三本账 → 面板」。
断言的是「该落盘的东西真的落了盘」，包括：

- 私聊回话、群里没点名不接、被 @ 回话、窗口命中不用 @ 也接
- 工具环：`calc` 真执行、结果回灌进第二轮提示词、工具调用有记账
- 改 `guard.perMinute` 立刻生效且写回磁盘
- 记忆跨 Runtime 重启还在；`panelView` 七个分区齐全、`notices` 为空；详情页能开、未知 id 优雅降级
- 事件 / 行为 / 审计三本账都非空，且**没有行为挂在不存在的事件上**
- 静态规则：`channel.say` 只允许出现在 `outbound` 与面板代发两处

这条脚本补的是静态守卫的盲区：`check-layers` 只能证明 import 没断，证明不了装配起来还能跑。

### 验证

```
npm test        37 个用例文件全过（通道 +1 项：通知/请求映射）
npm run smoke   17 项全通
npm run probe   104 项全过
check-layers    90 文件 / 175 依赖：无断链、无环、无越层、无绕闸
audit:config    88/88 键有消费者
audit:dead      215 个导出：死导出 0、自用导出 0
```

### 已知未接（记下来，不装作有）

- **连发合并**：`TAG.BURST` 与 `guard.mergeWindowMs` 有值、有标签，但没有消费者 ——
  私聊连发几条仍是逐条回。要接就得在 `onRaw` 前加缓冲窗口，代价是每条回复都晚 1~3 秒，
  属于体验取舍，不在本轮擅自改。
- **换目标的模型判定**：上游用一次内部调用判「旧目标是否已停」，这里只做廉价判据（见 0.35.0）。
- **说说 / 朋友圈**：通道有 `sendQzone`，但没有入口调它。
- **跨群记忆**：上游会把别的群的话题带一点进来，这里没有。

## 0.35.0 — 借来两件事：像人一样打字，以及知道在跟谁说话

外来实现来自 `jiangsuyuan/deepseek_QQFish_Service`（MIT）的单文件桥接层。取的是**两段逻辑**，
不是整个项目：那边的通道、登录、表情库、WebUI 跟这边重复，搬过来只会两套并存。
搬过来的两段各自成模块，接口按本项目的分层重写，不保留那边的函数名与全局变量。

### 一、`lib/typing.mjs` — 单线程拟人打字

原来只有 `guard.delay()` 一个固定节奏：首条 2.5 秒、每条之间 1.8 秒，与字数无关。
于是「嗯」和「三百字」等得一样久 —— 前者太慢（像卡了），后者太快（像粘贴）。改成分三层：

| 层 | 做什么 | 出处 |
|---|---|---|
| 时间模型 | `1.5s 基础 + 每字 0.5s + 0.3~1.2s 抖动`，下限 200ms、封顶 15s | 对方 `typingSecPerChar` / `thinkingBaseSec` / `maxTypingDelaySec` |
| 单线程 | 全局一条 Promise 链，私聊与群聊排同一队；上一条发完才轮到下一条 | 对方 `__typingMutex` |
| 分条留缝 | 自己 `[split]` 的段之间 1~3 秒，机器切的 0.5~1.4 秒 | 对方 `sendHuman` 里的 `isSelfSplit` |

- `guard.delay()` 没被废掉：它算出来的等待当下限（`max(打字时长, guard 等待)`），
  限流与夜间静音照旧由 guard 管。两层分工写进了模块开头。
- 「正在输入」走 NapCat 的 `set_input_status`（新增 `channel.inputStatus()`）。
  非标准接口，失败静默 —— 亮不出来只是少点真实感，不该拖累一条已生成的回复。
- 队列上限 5 条：超了就不再人为拖时间，只保证串行。丢内容比丢延迟糟得多。
- 顺带接上模型自己写的 `[split]` 标记（原来是死字面量，会被原样发出去）。

### 二、`lib/attention.mjs` — 群聊注意力账本

原来只有「会话级」活跃窗口（`runtime.markActive` / `isActive`）：一个群热着，
**谁说话都算接着说**。群里三个人聊天时，这就是抢话。改成按人记账：

- 窗口 = `会话 → 人 → {到期时间, 已聊轮数}`，长度/轮数上限沿用 `group.followUpSeconds`
  与 `group.followUpMaxTurns`，**没有新增配置键**（面板少一个旋钮，就少一处「改了没用」）。
- 换人判定：窗口里是 A，B 开口了 —— 只有「这句对着自己说（你/您）」或
  「与上一句二元组重合率 ≥ 0.2」才换人，换人时关掉 A 的窗口。不成立就当没听见。
- 判定在 `Turn.handle` 里先做，结果作为 `ctx.attention` 交给 `behavior.route`：
  路由仍是纯函数（同一个事件判两次结果一致），开窗关窗的副作用留在 turn。
- 路由里这条判定排在兴趣词之前：「对方正在跟我说话」比「我看到感兴趣的内容」硬，
  否则统计里「被搭话」和「主动接话」会混成一类。

### 三、顺手清掉的一处隐患

`lib/channel/onebot.mjs` 是 10 月 30 日的旧副本（834 行，没有存活检测），
与真正加载的 `lib/qq/onebot.mjs`（968 行）并存且无人 import ——
改错文件时界面毫无变化，是本轮真实踩到的坑（第一版 `inputStatus` 就写进了那份死文件）。
已删除 `lib/channel/`，通道只剩一份。

### 验证

```
npm test                37 个用例文件全过（新增 typing 12 项、attention 13 项、回合 +3 项）
npm run probe           104 项全过
check-layers            85 文件 / 157 依赖：无断链、无环、无越层、无绕闸
audit:config            88/88 键有消费者
audit:dead              215 个导出：死导出 0、自用导出 0
```

### 升级注意

- 不需要改配置，不需要装依赖（两段逻辑都是纯 Node，零第三方包）。
- 同步到 profile 后**必须重启 DeepSeek Harness**，否则进程里还是旧模块。

## 0.34.7 — 链路盘点：补上几处「看着没事、实际没兜住」的分支

这一版不新增能力，只把自查里查出来的空洞堵上。判定标准只有一条：
**问题是不是真能被触发，以及现有用例能不能抓住它**（每一处都做了「撤销修复 → 看用例红不红」）。

- `lib/coding.mjs`
  - `searchSource` 补 `existsSync` 守卫。同组三个工具里只有它缺这一句，
    路径不存在时 `statSync` 直接抛 ENOENT 冒出函数，上层只能兜成通用的 `tool_failed`，
    和 `listTree` / `readSource` 的 `missing` 对不齐。
  - `backupTo` 的 `mkdirSync` 从 try 外面挪进里面。备份目录建不出来时，
    原先抛的是 `io`（"没写成"），而实际是"备份没做成、文件一个字没动" —— 两件事被混成一个错。
  - 备份失败时**中止写入**，返回 `no_backup`。模块开头写着"备份必须在写之前成功"，
    而 `backupTo` 内部是吞异常的，不判 null 那句约定就只是句注释。
- `lib/sandbox.mjs`
  - 清理老目录时跳过**正在跑**的那几份：`run()` 是异步的，两次并发调用时后一次在
    `#execute` 开头就会走到 `#prune`，把前一次还在用的目录删掉。前一次随后读 stdout 读到空，
    `classify()` 给出 exit=0 的「跑完了，没有输出」—— 不是报错，是**静默的错误结果**。
    修法是先登记 `active`，清理时从候选里剔掉，finally 里注销。
- `lib/panel.mjs` / `lib/panel-view.mjs`
  - 档位中文名过去抄了两份。上一版把「跑代码」改成「沙箱」时，只改了 `panel.mjs` 那一份，
    面板视图里那份还在 —— 这正是"界面没变"这类问题的根源。
    现在统一走 `optionLabelsOf(key)`，只有一个出处。
- `lib/host.mjs` — `workspaceOf()` 改指 `<数据目录>/sandbox/workspace`，
  与沙箱真正创建的目录是同一个（此前指向一个没人建的路径）。
- 测试：`coding` 19 项、`sandbox` 22 项、`panel-view` 39 项、`host` 8 项。
  其中「清理跳过在飞目录」改成断言**登记/注销机制**而不是"目录还在" ——
  后者在 Windows 上恒绿（stdout.log 被两方持句柄，rmSync 删不掉，有没有保护表现一样）。

## 0.34.6 — 沙箱：草稿纸终于存在了，名字也终于统一了

### 一、工作区目录从来没有被创建出来

`file_read` 一直把 `<数据目录>/workspace` 当根目录读，而**没有任何一行代码去 `mkdir` 它**。
唯一的 `workspaceOf()` 只是把路径拼好、传给了 `createHostRunner` 的 `workspace` 参数 ——
而那个函数压根不读这个参数。于是这个工具永远只能回「只能读工作目录里的文件」，
看着像权限问题，实际是没人建过那个目录。

更实质的问题是：沙箱每跑一次就新建一个一次性目录，写完跑完被 `#prune` 回收，
**深蓝每跑一次代码都要从零开始** —— 上次写的脚本、攒了一半的稿子，全都不在。

现在有了草稿纸：`<数据目录>/sandbox/workspace`。

| 位置 | 权限 | 留不留 |
|---|---|---|
| 源码树（`E:\深蓝鲸`） | 只读 + 关键文件要 `force` | 改一笔备份一笔 |
| 运行目录 `out/` | 可写 | 跟着这次运行走，用完回收 |
| **工作区 `sandbox/workspace`** | **读 + 写** | **跨运行留存** |

- `Sandbox` 构造时就 `mkdir`，不用等第一次跑代码；失败不抛（数据目录不可写时让插件活着比让沙箱崩了好），由 `status().workspaceReady` 如实反映。
- 子进程同时 `--allow-fs-read` / `--allow-fs-write` 到工作区，并用 `SANDBOX_WORKSPACE` 环境变量告诉代码地方在哪。
- 工具侧按 `area` 分流：不填 = 源码（老行为完全不变），`"area":"work"` = 草稿纸。
- 挂在 `sandbox/` 下面而不是数据目录根部，一是它是沙箱的一部分，二是 `#prune` 只清理名字像 `s1743...-01` 的运行目录，永远不会误删它。

### 二、名字收敛到「沙箱」（以及为什么改完界面还是老样子）

同一种能力过去有两个中文名在打架：文档写「沙箱」，面板那一组却叫**「跑代码」**。
于是文档里那句「设置 → 沙箱 → 改代码档位」是找不到入口的 —— 面板上根本没有叫「沙箱」的组。

**改完之后界面仍然显示「跑代码」。原因不在代码，在加载路径：**

profile 的依赖写的是 `"dsh-shenlan-whale": "file:E:/深蓝鲸"`，而 pnpm 对 `file:` 依赖是
**复制**一份到 `~/.dsh/profiles/<profile>/node_modules/` 下，不是软链接。
宿主加载的是那一份快照。改 `E:\深蓝鲸` 改得再多、重启多少次，加载的都还是 01:37 复制过去的那版 ——
它里面既没有新的组名，也没有 `codeMode` 这一项。

所以：
- **改完源码必须同步一次再重启**。这件事现在是一条命令：`npm run sync`（加到 `npm test` 之外的独立脚本）。
- `npm run check:sync` 只比对不复制，退出码非 0 就说明副本落后了。
- `scripts/verify-coding-tools.mjs` 里也加了这一条断言 —— 「宿主加载的副本与源码同版本」，
  下次再出现「界面没变」时，它会先一步指出来，而不是让人对着代码和界面反复怀疑。

英文标识 `sandbox.*` 与文件名不动 —— 改的是给人看的字，不是给机器读的键。

现在统一叫**沙箱**（分组名、工具名 `exec_sandbox`、执行器拒绝文案里的路径、`今日沙箱运行`、
技能页、以及 CONCEPTS / SCHEME / UX 三份文档里的说法）。英文标识 `sandbox.*` 与文件名不动 ——
改的是给人看的字，不是给机器读的键。

**改代码档位**（`sandbox.codeMode`：off / read / write）此前确实没出现在面板上 ——
那是宿主还没重载新代码；重启之后它就在「设置 → 沙箱」这一组里，三档都带中文说明。

## 0.34.5 — 「聊着聊着突然不理人」：主人被自己的限流挡在门外

现场：私聊里连着聊了半小时之后，机器人**一条都不回**了 —— 消息在聊天页面看得到，
通道显示在线，面板一切正常，就是不答话。重启之后立刻恢复。

查 `behaviors.jsonl`，三条记录把话说死了：

```
02:33:10  trigger=per_hour  ok=false  「这一小时已经说了 31 条，到上限了」
02:41:14  trigger=per_hour  ok=false  同上
02:41:47  trigger=per_hour  ok=false  同上   ← 主人问「你人呢」的那一句
```

**根因**：`guard.replyQuotaPerHour`（面板上写的就是「每群每小时最多回几条」）当时是 30，
而 `Guard.check()` 里**只有夜间和临时静音认主人，`per_minute` / `per_hour` 两条闸不看是谁**。
于是主人跟自己的机器人说话，也算在「防刷屏」的额度里。

三个缺陷叠在一起，才让它变成这么难查的故障：

| 缺陷 | 表现 | 改成 |
|---|---|---|
| 主人也被每小时总量拦 | 聊密一阵就彻底失声 | **主人不受总量限制**；分钟闸门保留，且兜底下限 15 条/分（防模型抽风连发，那不是人情问题） |
| 被拦时什么都不说 | 日志里有 `per_hour`，人只看得见沉默，唯一能想到的是重启 | 主人被拦时说一句为什么，同一会话一小时最多一次（否则它自己成了刷屏源）；别人被拦保持安静 —— 那才是正确反应 |
| 限流计数漏了一半 | 自然小时发了 61 条，Guard 只数到 31，限流随机失效又随机生效 | 「说出去了 = 算一次」收敛到 `noteSelf()` 一个出口，原先手写在两处，其余十来处主动发送一个都没记 |

计数为什么必须只有一个出口：漏记比多记难查得多。多记是「说话变慢」，
漏记是「面板显示 12 条、实际发了 40 条」，限流于是变成一件随机的事。

## 0.34.4 — 让它能改自己的代码（但不许改垮）

现场：他/她能跑一次性代码（`exec_sandbox`），却看不懂自己 —— `file_read` 只能读数据目录里的
`workspace/`，沙箱进程的权限只到自己的运行目录。于是「哪里不对」永远要靠人来改，
而人不在的时候，它就只能带着 bug 继续跑。

**根因**：读源码的能力（另一条产品线上早就有 `read_source`）从来没有长到深蓝这边；
而写源码这件事，需要的不是权限，是边界。所以这一次两件事一起做。

| 新增 | 作用 | 边界 |
|---|---|---|
| `code_list` / `code_read` / `code_search` | 列、看、搜自己这套源码（带行号、带上下文） | 路径必须落在插件目录内；`node_modules` 不进结果 |
| `code_write` | 新建或整份覆盖一个文件 | 改前必备份；关键启动文件默认拒，要点头（`force: true`）才行 |
| `code_restore` | 把最近一份备份放回去 | 改崩了自己之后唯一的后悔药 |
| `run_command` | 在插件目录里跑 node / npm / npx | 不经 shell，参数是数组；白名单之外一律不跑；超时就掐 |

一道总闸 `sandbox.codeMode`：`off` 一眼不许看 / `read` 只看 / `write` 才能改能跑。
它和旧的 `sandbox.mode` 是**两件事** —— `mode` 管「临时跑一段代码」（炸了是一次失败），
`codeMode` 管「碰不碰源码」（炸了是下次起不来）。风险不对称，闸门就该分开。

沙箱进程同时把源码目录作为**只读**挂载过去（`--allow-fs-read`），写权限仍然只有 `out/` 一个出口：
能读哪儿和能写哪儿必须分开收紧，否则「看一眼」随时变成「动一下」。

**为什么不直接把写权限也给沙箱**：沙箱是 Node 权限模型，粒度到不了「这个文件能改、那个不能」。
所以写这件事走宿主侧的受控工具（备份、禁区、审计都在 `lib/coding.mjs` 一处判），
而不是给子进程开更大的窗。

## 0.34.3 — 说话的节奏：单位兜底 + 不重启也能改

现场：面板上「看到消息先等多久 / 两条之间至少隔多久」显示 **0.0003 秒**。
配置里躺着的值是 **0.3**，而这一项存的是**毫秒** —— 实际是 0.3 毫秒，等于秒回。
秒回既像机器人，又是 QQ 风控最敏感的行为特征（此前 `result 1006514` 的合适嫌疑）。
更麻烦的是：磁盘上的 config.json 已被自动修好，但**宿主进程内存里那份还是旧值**，
面板读内存、节奏也读内存，于是怎么点都改不回来。

**根因**：时长项「存毫秒、显秒」的换算**只写在前端**（`×scale` 存、`÷scale` 显），
服务端 `set()` 完全不换算。任何绕过前端的写入（脚本、迁移、手改）都会把「秒」的数值当毫秒存进去。

| 修正 | 原来 | 现在 |
|---|---|---|
| 时长单位换算只靠前端 | 绕过前端写进来的值会变成 0.3 毫秒 | 服务端 `validate()` 按**存储单位**判定，越界如实拒绝；启动阶段由 `migrate` 兜回毫秒级默认值 |
| 节奏层没有下限防护 | 脏值进了内存就直接变成秒回 | `guard.delay()` 认出「正数却小到不像毫秒」的值，按秒解释，兜住 0.3 秒下限 |
| 改了磁盘必须重启才生效 | 内存与磁盘长期分叉，排查靠重启 | 新增 `runtime.reloadConfig()` 与 `POST /api/shenlan/config/reload`：重新按磁盘装配一遍，不用重启 DSH |

**为什么不做「自动换算单位」**：猜用户意图风险更大 —— 会把「想快点回（10 毫秒，非法）」
放大成「等 10 秒」，比如实拒绝更难查。宁可如实拒绝 + 兜回默认值。

### 节奏参数：调成普通人聊天的停顿

| 项 | 原值 | 现值 | 依据 |
|---|---|---|---|
| 看到消息先等多久 | 2000 ms | **2500 ms** | 人看到消息→想一下→开始打字，约 2~3 秒；秒回像机器人，再久像掉线 |
| 两条之间至少隔多久 | 1200 ms | **1800 ms** | 人连发两条，中间要重新想、重新打 |
| 连续几条合并成一次回 | 2000 ms | **3000 ms** | 对方还在打字，别插嘴 |

配合原有的积压拉长（一分钟发满 5 条后每多一条 +400ms，最多 +3s）与 8 秒上限，
整体落在「像人在打字」的区间。

## 能力基线 — 连接稳得住、图片留得下

### 一、连接稳定性：四个会「慢慢不稳」的毛病

| 毛病 | 表现 | 改成 |
|---|---|---|
| 旧 socket 迟到的 `close` 没被忽略 | 越连越多：一条断开把新连接打成 offline，再触发重连 | 每个事件先判 `this.ws === ws`，旧 socket 的事件一律丢掉；`#connect` 发现已有一条 CONNECTING/OPEN 就不再新建 |
| 没有存活检测 | 换网/协议端假死时 socket 不 close，面板一直显示在线，所有发送都在等 8 秒超时 | 记录 `lastFrameAt`（心跳也算），90 秒没帧 → 主动断开重连；每 15 秒体检一次 |
| 退避被抖动清零 | 连上 1 秒就断 → 退避又回 1 秒，变成高频重连 | 连满 30 秒才算「稳过」，只有稳过的断开才清零退避；上限 60 秒，带 ±15% 抖动 |
| 往死 socket 里写 | 消息静默丢失，然后超时 | `sendRaw` 检查 `readyState === 1`，不是就当场报「通道正在断开」 |

另外：`close` 的 code / reason 现在会写进日志（`code 1006`、`code 1008` 各指一件事，以前全看不见）。

### 二、图片本体：收到就落盘

以前一条图片消息只留下两个东西：会过期的 CDN `url`、协议端的临时文件名 `file`。
所以「收藏这张表情」失败、翻历史看不到图、面板十分钟后裂图 —— 根子上是**本体从没落到我们盘上**。

新增 `lib/media.mjs`：

- 收图即存：`attachImages()` 在事件进入流程前挂一个落盘承诺（不 await，不卡消息）；
- 内容寻址：文件名是内容 sha1，同一张图收十次也只有一份；
- 三条取图路：本地已有文件 → 协议端 `get_image` 的 base64 → 下载 url，逐级降级；
- 只认文件头、不认后缀，非图片（比如登录页）拒收；
- 定期清理：启动时删掉 30 天前 / 超过 3000 张的缓存。

配套：

- `save_sticker` 优先用落盘的那份；**用户先发图、再发一句「收藏这个表情」也能存**（往上翻最近一条带图的事件）；
- 新增 `GET /api/shenlan/media/<名字>`，面板与导出不再依赖会过期的链接；
- `turn.mjs` 的看图路径同样优先用本地副本。

### 三、验证

- `npm test`：34 个用例文件、624 条断言全过（本版新增 8 条：单位兜底 3、节奏下限 3、重载 2）
- `check-layers`：80 个文件 / 150 条依赖，无断链、无环、无越层、无绕闸
- `audit:config` 87/87；`audit:dead` 197 个导出：死导出 0、自用导出 0
- `npm run probe`：104 项端到端全过
- 线上：部署后热重载回到 online，`channel_state` 无抖动；`GET /media/<名字>` 实测 200、字节一致、`../` 得 404
